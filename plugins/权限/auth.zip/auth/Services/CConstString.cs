﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace auth.Server
{
    public static class CConstString
    {
        public const string ConnectName = "TestEPES";
        public const string UserId = "admin";
        public const string AppName = "CRTM";
    }
}
