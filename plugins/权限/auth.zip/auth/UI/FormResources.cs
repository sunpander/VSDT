﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using DevExpress.XtraEditors;
using auth.Server;

namespace auth.UI
{
    /// <summary>
   /*样式:上面是画面,下面是按钮
    功能:画面管理,按钮管理...  按钮 :查询, 维护(grid上显示增删改),保存,取消
    后台服务:
    查询画面 ---------传入画面名,含模糊查询       ---返回执行结果
    查询按钮--传入画面名                  ---返回执行结果
    画面保存----------传入画面的新增,修改,删除信息---返回执行结果
    按钮保存----------传入按钮的新增,修改,删除信息---返回执行结果
    [菜单管理.其他资源管理.暂时先不做] 
    */
    /// </summary>
    public partial class FormResources : DevExpress.XtraEditors.XtraForm
    {
        #region 私有变量
        //图标编号
        private const int FOLDERICON = 0;
        private const int FOLDERICON_EXPAND = 1;
        private const int FORMICON = 2;
        private const int BUTTICON = 3;
        private const int RESGROUPICON = 0;
        private const int OTHICON = 7;

        private const int SAVE = 13;
        private const int DISCARD = 14;

        private string formName = ""; //所属画面名
        private string appName = ""; //所属画面名的子系统

        private ArrayList buttons = new ArrayList();
     
  
        #endregion
        
        public FormResources()
        {
            InitializeComponent();
        }


        private void InitDevGridCustomButtons()
        {
            ((ImageList)this.fgDevGridFormInfo.EmbeddedNavigator.Buttons.ImageList).Images.Add(this.imageList.Images[0]);
            ((ImageList)this.fgDevGridFormInfo.EmbeddedNavigator.Buttons.ImageList).Images.Add(this.imageList.Images[1]);

            this.fgDevGridFormInfo.EmbeddedNavigator.Buttons.CustomButtons.AddRange(new NavigatorCustomButton[] {
            new NavigatorCustomButton(SAVE, "保存"),
            new NavigatorCustomButton(DISCARD, "放弃")            
            });

            ((ImageList)this.fgDevGridButtInfo.EmbeddedNavigator.Buttons.ImageList).Images.Add(this.imageList.Images[0]);
            ((ImageList)this.fgDevGridButtInfo.EmbeddedNavigator.Buttons.ImageList).Images.Add(this.imageList.Images[1]);

            this.fgDevGridButtInfo.EmbeddedNavigator.Buttons.CustomButtons.AddRange(new NavigatorCustomButton[] {
            new NavigatorCustomButton(SAVE, "保存"),
            new NavigatorCustomButton(DISCARD, "放弃")
            });

            fgDevGridFormInfo.EmbeddedNavigator.Buttons.CustomButtons[DISCARD].Visible = false;
            fgDevGridFormInfo.EmbeddedNavigator.Buttons.CustomButtons[SAVE].Visible = false;
            fgDevGridButtInfo.EmbeddedNavigator.Buttons.CustomButtons[DISCARD].Visible = false;
            fgDevGridButtInfo.EmbeddedNavigator.Buttons.CustomButtons[SAVE].Visible = false;

            this.fgDevGridFormInfo.EmbeddedNavigator.ButtonClick += new NavigatorButtonClickEventHandler(FormInfoEmbeddedNavigator_ButtonClick);
            this.fgDevGridButtInfo.EmbeddedNavigator.ButtonClick += new NavigatorButtonClickEventHandler(ButtInfoEmbeddedNavigator_ButtonClick);
        }

  
        private void SetPageState(bool editMode)
        {
            barButtonItemEdit.Enabled = !editMode;
            barButtonItemSave.Enabled = editMode;
            barButtonItemCancel.Enabled = editMode;

            fgDevGridFormInfo.ShowAddRowButton = editMode;
            fgDevGridFormInfo.ShowAddCopyRowButton = editMode;
            fgDevGridFormInfo.ShowDeleteRowButton = editMode;
            fgDevGridFormInfo.SetAllColumnEditable(editMode);

            fgDevGridButtInfo.ShowAddRowButton = editMode;
            fgDevGridButtInfo.ShowAddCopyRowButton = editMode;
            fgDevGridButtInfo.ShowDeleteRowButton = editMode;
            fgDevGridButtInfo.SetAllColumnEditable(editMode);
            colFNAME.OptionsColumn.AllowEdit = false;
            colAPPNAME1.OptionsColumn.AllowEdit = false;

            fgDevGridFormInfo.EmbeddedNavigator.Buttons.CustomButtons[DISCARD].Visible = editMode;
            fgDevGridFormInfo.EmbeddedNavigator.Buttons.CustomButtons[SAVE].Visible = editMode;
            fgDevGridButtInfo.EmbeddedNavigator.Buttons.CustomButtons[DISCARD].Visible = editMode;
            fgDevGridButtInfo.EmbeddedNavigator.Buttons.CustomButtons[SAVE].Visible = editMode;

            fgDevGridFormInfo.ShowContextMenu = editMode;
            fgDevGridButtInfo.ShowContextMenu = editMode;

        }


        #region 查询
        /// <summary>
        /// 查询按钮
        /// </summary>
        private void QueryButton()
        {
            layoutControlGroup2.Text = "画面["+formName+"]按钮";
            if (formName == string.Empty) return;
            DataSet inblk = new DataSet();
            inblk.Tables.Add();
            inblk.Tables[0].Columns.Add("fname");
            inblk.Tables[0].Rows.Add(formName );

            DataTable dt = DbResource.QueryButtonInfo(inblk, CConstString.ConnectName);
            dt.AcceptChanges();
            fgDevGridButtInfo.DataSource = dt;
            gridViewButtInfo.BestFitColumns();
        }


        private void QueryForm()
        {
            DataSet inblk = new DataSet();
            inblk.Tables.Add();
            inblk.Tables[0].Columns.Add("name");
            inblk.Tables[0].Columns.Add("dllname");
            inblk.Tables[0].Columns.Add("appname");
            inblk.Tables[0].Rows.Add(fgtFormName.Text, fgtDllName.Text, "");

            DataTable dt = DbResource.QueryFormInfo(inblk, CConstString.ConnectName);
            dt.AcceptChanges();
            fgDevGridFormInfo.DataSource = dt;
            gridViewFormInfo.BestFitColumns();
            if (dt != null & dt.Rows.Count > 0)
            {
                formName = dt.Rows[0]["name"].ToString();
                QueryButton();
            }
        }
        #endregion


        #region 其他方法


        private void CancelEdit()
        {
            if (MessageBox.Show("是否退出维护模式？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                SetPageState(false);

                if (isChange(fgDevGridFormInfo))
                {
                    QueryForm();
                }

                if (isChange(fgDevGridButtInfo))
                {
                    QueryButton();
                }
            }
        }


        private bool isChange(EF.EFDevGrid grid)
        {
            grid.MainView.PostEditor();
            grid.RefreshDataSource();
            DataTable table = grid.DataSource as DataTable;
            if (table == null)
                return false;
            for (int rowIndex = 0; rowIndex < table.Rows.Count; ++rowIndex)
            {
                if (table.Rows[rowIndex].RowState == DataRowState.Deleted || table.Rows[rowIndex].RowState == DataRowState.Added || table.Rows[rowIndex].RowState == DataRowState.Modified)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// 检查数据正确性
        /// </summary>
        /// <returns></returns>true 正确 false 存在问题
        private bool formCheck()
        {
            //检查数据准确性
            for (int i = 0; i < this.gridViewFormInfo.RowCount; i++)
            {
                if (gridViewFormInfo.GetDataRow(i).RowState == DataRowState.Added || gridViewFormInfo.GetDataRow(i).RowState == DataRowState.Modified)
                {
                    if (/*gridViewFormInfo.GetRowCellValue(i, "selected") == null
                     || gridViewFormInfo.GetRowCellValue(i, "selected").ToString() == "False"*/
                        !fgDevGridFormInfo.GetSelectedColumnChecked(i))
                    {
                        //continue;
                    }
                    if (gridViewFormInfo.GetRowCellValue(i, "NAME") != null)
                    {
                        if (gridViewFormInfo.GetRowCellValue(i, "NAME").ToString().Trim() == "")
                        {
                            MessageBox.Show(EP.EPES.EPESC0000033/*画面名不能为空，请重新输入！*/, EP.EPES.EPESC0000034/*输入信息不合法*/, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return false;
                        }
                        string formname = gridViewFormInfo.GetRowCellValue(i, "NAME").ToString();
                        //for (int j = 0; j < formname.Length; j++)
                        //{
                        //    if (formname[j] < 48 || (formname[j] > 57 && formname[j] < 65) || formname[j] > 90)
                        //    {
                        //        MessageBox.Show(EP.EPES.EPESC0000121/*画面名必须是大写字母与数字的组合，请重新输入！*/, EP.EPES.EPESC0000034/*输入信息不合法*/, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        //        return false;
                        //    }
                        //}
                        if (formname.Length > 128)
                        {
                            MessageBox.Show(EP.EPES.EPESC0000037/*画面名最多允许输入128位，请重新输入！*/, EP.EPES.EPESC0000034/*输入信息不合法*/, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return false;
                        }

                        if (formname.Length < 2)
                        {
                            MessageBox.Show(EP.EPES.EPESC0000038/*请输入2位以上的画面名！*/, EP.EPES.EPESC0000034/*输入信息不合法*/, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return false;
                        }
                    }
                    else
                    {
                        MessageBox.Show(EP.EPES.EPESC0000033/*画面名不能为空，请重新输入！*/, EP.EPES.EPESC0000034/*输入信息不合法*/, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return false;
                    }

                    if (gridViewFormInfo.GetRowCellValue(i, "DESCRIPTION") != null)
                    {
                        if (gridViewFormInfo.GetRowCellValue(i, "DESCRIPTION").ToString().Trim() == "")
                        {
                            MessageBox.Show(EP.EPES.EPESC0000035/*画面描述不能为空，请重新输入！*/, EP.EPES.EPESC0000034/*输入信息不合法*/, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return false;
                        }
                    }
                    else
                    {
                        MessageBox.Show(EP.EPES.EPESC0000035/*画面描述不能为空，请重新输入！*/, EP.EPES.EPESC0000034/*输入信息不合法*/, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return false;
                    }

                    if (gridViewFormInfo.GetRowCellValue(i, "DLLNAME") != null)
                    {
                        if (gridViewFormInfo.GetRowCellValue(i, "DLLNAME").ToString().Trim() != "")
                        {
                            string dllname = gridViewFormInfo.GetRowCellValue(i, "DLLNAME").ToString().ToUpper();
                            if (dllname.Length > 4 && dllname.Substring(dllname.Length - 4, 4) == ".DLL")
                            {
                                for (int j = 0; j < dllname.Length - 4; j++)
                                {
                                    if (dllname[j] < 48 || (dllname[j] > 57 && dllname[j] < 65) || (dllname[j] > 90 && dllname[j] != 95))
                                    {
                                        MessageBox.Show(EP.EPES.EPESC0000040/*动态库必须由数字、字母或下划线加'.DLL'组成，请重新输入！*/, EP.EPES.EPESC0000034/*输入信息不合法*/, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                        return false;
                                    }
                                }
                            }
                            else
                            {
                                MessageBox.Show(EP.EPES.EPESC0000040/*动态库必须由数字、字母或下划线加'.DLL'组成，请重新输入！*/, EP.EPES.EPESC0000034/*输入信息不合法*/, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return false;
                            }
                        }
                        else
                        {

                            MessageBox.Show(EP.EPES.EPESC0000161/*动态库不能为空，请重新输入！*/, EP.EPES.EPESC0000034/*输入信息不合法*/, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return false;

                        }
                    }
                    else
                    {

                        MessageBox.Show(EP.EPES.EPESC0000161/*动态库不能为空，请重新输入！*/, EP.EPES.EPESC0000034/*输入信息不合法*/, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return false;
                    }

                    if (gridViewFormInfo.GetRowCellValue(i, "ABBREV") != null)
                    {
                        if (gridViewFormInfo.GetRowCellValue(i, "ABBREV").ToString().Length > 10)
                        {
                            MessageBox.Show(EP.EPES.EPESC0000041/*缩写最多允许输入10位，请重新输入！*/, EP.EPES.EPESC0000034/*输入信息不合法*/, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return false;
                        }
                    }

                    if (gridViewFormInfo.GetRowCellValue(i, "ICONNUM") != null)
                    {
                        if (gridViewFormInfo.GetRowCellValue(i, "ICONNUM").ToString().Length > 3)
                        {
                            MessageBox.Show(EP.EPES.EPESC0000042/*图标编号最多允许输入3位，请重新输入！*/, EP.EPES.EPESC0000034/*输入信息不合法*/, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return false;
                        }
                    }

                    if (gridViewFormInfo.GetRowCellValue(i, "FORM_CALL_MODE") != null)
                    {
                        if (gridViewFormInfo.GetRowCellValue(i, "FORM_CALL_MODE").ToString().Length > 1)
                        {
                            MessageBox.Show(EP.EPES.EPESC0000043/*调用方式最多允许输入1位，请重新输入！*/, EP.EPES.EPESC0000034/*输入信息不合法*/, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return false;
                        }
                    }

                    if (gridViewFormInfo.GetRowCellValue(i, "DLLPATH") != null)
                    {
                        if (gridViewFormInfo.GetRowCellValue(i, "DLLPATH").ToString().Length > 500)
                        {
                            MessageBox.Show(EP.EPES.EPESC0000044/*调用路径最多允许输入500位，请重新输入！*/, EP.EPES.EPESC0000034/*输入信息不合法*/, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return false;
                        }
                    }
                }
            }
            return true;
        }

        private bool btnCheck()
        {

            //检查数据准确性
            for (int i = 0; i < this.gridViewButtInfo.RowCount; i++)
            {
                if (//gridViewButtInfo.GetRowCellValue(i, "selected") == null
                    //|| gridViewButtInfo.GetRowCellValue(i, "selected").ToString() == "False"
                    !fgDevGridButtInfo.GetSelectedColumnChecked(i))
                {
                    continue;
                }
                if (gridViewButtInfo.GetRowCellValue(i, "NAME") != null)
                {
                    if (gridViewButtInfo.GetRowCellValue(i, "NAME").ToString().Trim() == "")
                    {
                        MessageBox.Show(EP.EPES.EPESC0000052/*按钮名不能为空，请重新输入！*/, EP.EPES.EPESC0000034/*输入信息不合法*/, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return false;
                    }
                    if (gridViewButtInfo.GetRowCellValue(i, "NAME").ToString().Length < 2)
                    {
                        MessageBox.Show(EP.EPES.EPESC0000051/*请输入大于两位的按钮名！*/, EP.EPES.EPESC0000034/*输入信息不合法*/, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return false;
                    }
                    //if (Utility.GetByteLength(gridViewButtInfo.GetRowCellValue(i, "NAME").ToString()) > 125)
                    //{
                    //    MessageBox.Show(EP.EPES.EPESC0000050/*按钮名不能超过125位，请重新输入！*/, EP.EPES.EPESC0000034/*输入信息不合法*/, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    //    return false;
                    //}
                }
                else
                {
                    MessageBox.Show(EP.EPES.EPESC0000052/*按钮名不能为空，请重新输入！*/, EP.EPES.EPESC0000034/*输入信息不合法*/, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

                //if (gridViewButtInfo.GetRowCellValue(i, "FNAME") != null)
                //{
                //    if (gridViewButtInfo.GetRowCellValue(i, "FNAME").ToString().Trim() == "")
                //    {
                //        MessageBox.Show(EP.EPES.EPESC0000192/*所属画面不能为空，请重新输入！*/, EP.EPES.EPESC0000034/*输入信息不合法*/, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //        return false;
                //    }
                //}
                //else
                //{
                //    MessageBox.Show(EP.EPES.EPESC0000192/*所属画面不能为空，请重新输入！*/, EP.EPES.EPESC0000034/*输入信息不合法*/, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //    return false;
                //}


                if (gridViewButtInfo.GetRowCellValue(i, "DESCRIPTION") != null)
                {
                    if (gridViewButtInfo.GetRowCellValue(i, "DESCRIPTION").ToString().Trim() == "")
                    {
                        MessageBox.Show(EP.EPES.EPESC0000048/*按钮描述不能为空，请重新输入！*/, EP.EPES.EPESC0000034/*输入信息不合法*/, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return false;
                    }
                    //if (Utility.GetByteLength(gridViewButtInfo.GetRowCellValue(i, "DESCRIPTION").ToString()) > 75)
                    //{
                    //    MessageBox.Show(EP.EPES.EPESC0000047/*按钮描述不能超过75位，请重新输入！*/, EP.EPES.EPESC0000034/*输入信息不合法*/, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    //    return false;
                    //}
                }
                else
                {
                    MessageBox.Show(EP.EPES.EPESC0000048/*按钮描述不能为空，请重新输入！*/, EP.EPES.EPESC0000034/*输入信息不合法*/, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

                //只有按钮名为F1-F12时，操作类型才能选择多步操作
                if (gridViewButtInfo.GetRowCellValue(i, "OPTYPE") != null)
                {
                    if (gridViewButtInfo.GetRowCellValue(i, "OPTYPE").ToString() == "")
                    {
                        MessageBox.Show(EP.EPES.EPESC0000144/*操作类型不能为空，请重新输入！*/, EP.EPES.EPESC0000034/*输入信息不合法*/, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return false;
                    }

                    string name = gridViewButtInfo.GetRowCellValue(i, "NAME").ToString().Trim();
                    int num = 0;
                    if (name.Length > 1 && name.Substring(0, 1) == "F" && name.Substring(1, 1) != "0")
                    {
                        try
                        {
                            num = Int32.Parse(name.Substring(1));
                        }
                        catch
                        {
                            num = -1;
                        }
                        if ((num < 1 || num > 12) && (gridViewButtInfo.GetRowCellValue(i, "OPTYPE").ToString() == "B"))
                        {
                            MessageBox.Show(EP.EPES.EPESC0000053/*按钮名为F1-F12时操作类型才能选择“多步操作”！*/, EP.EPES.EPESC0000122/*无法选择“多步操作”*/, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return false;
                        }
                    }
                    else
                    {
                        if (gridViewButtInfo.GetRowCellValue(i, "OPTYPE").ToString() == "B")
                        {
                            MessageBox.Show(EP.EPES.EPESC0000053/*按钮名为F1-F12时操作类型才能选择“多步操作”！*/, EP.EPES.EPESC0000122/*无法选择“多步操作”*/, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return false;
                        }
                    }
                }
                else
                {
                    MessageBox.Show(EP.EPES.EPESC0000144/*操作类型不能为空，请重新输入！*/, EP.EPES.EPESC0000034/*输入信息不合法*/, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
            }
            return true;

        }

        #endregion

        #region 保存
        private void SaveData()
        {
            bool succsee = true;

            if (isChange(fgDevGridFormInfo))
            {
                if (formCheck())
                {
                    if (SaveFormInfo())
                    {
                        QueryForm();
                    }
                    else
                    {
                        succsee = false;
                    }
                }
                else
                {
                    succsee = false;
                }
            }

            if (isChange(fgDevGridButtInfo))
            {
                if (btnCheck())
                {
                    if (SaveButtInfo())
                    {
                        QueryButton();
                    }
                    else
                    {
                        succsee = false;
                    }
                }
                else
                {
                    succsee = false;
                }
            }

            if (succsee)
            {
                SetPageState(false);
            }
        }

        private bool SaveFormInfo()
        {
            DataTable dt = fgDevGridFormInfo.DataSource as DataTable;
            if (dt == null || dt.Rows.Count < 1)
                return false;

            DataTable instable = dt.Clone();
            DataTable deltable = dt.GetChanges(DataRowState.Deleted);
            DataTable updtable = dt.Clone();

            DataRow dr = null;
            for (int rowIndex = 0; rowIndex < gridViewFormInfo.RowCount; ++rowIndex)
            {
                if (fgDevGridFormInfo.GetSelectedColumnChecked(rowIndex))
                {
                    dr = gridViewFormInfo.GetDataRow(rowIndex);
                    if (dr.RowState == DataRowState.Added)
                    {
                        instable.Rows.Add(dr.ItemArray);
                    }
                    else if (dr.RowState == DataRowState.Modified)
                    {
                        updtable.Rows.Add(dr.ItemArray);
                    }
                }
            }

            DataSet inBlock = new DataSet();
            if (instable != null && instable.Rows.Count > 0)
            {
                instable.TableName = "INSERT_BLOCK";
                inBlock.Tables.Add(instable);
            }
            if (deltable != null && deltable.Rows.Count > 0)
            {
                deltable.RejectChanges();
                deltable.TableName = "DELETE_BLOCK";
                inBlock.Tables.Add(deltable);
            }
            if (updtable != null && updtable.Rows.Count > 0)
            {
                updtable.TableName = "UPDATE_BLOCK";
                inBlock.Tables.Add(updtable);
            }
            if (inBlock.Tables.Count > 0)
            {
                string msg = DbResource.SaveFormInfo(inBlock, CConstString.ConnectName);
                MessageBox.Show(msg, "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            if (gridViewFormInfo.FocusedRowHandle < 0)
            {
                formName = "";
            }
            else
            {
                formName = gridViewFormInfo.GetRowCellValue(gridViewFormInfo.FocusedRowHandle, "NAME").ToString();
            }
            QueryButton();
            return true;
        }


        private bool SaveButtInfo()
        {
            DataTable dt = fgDevGridButtInfo.DataSource as DataTable;
            if (dt == null || dt.Rows.Count < 1)
                return false;

            DataTable instable = dt.Clone();
            DataTable deltable = dt.GetChanges(DataRowState.Deleted);
            DataTable updtable = dt.Clone();

            DataRow dr = null;
            for (int rowIndex = 0; rowIndex < gridViewButtInfo.RowCount; ++rowIndex)
            {
                if (fgDevGridButtInfo.GetSelectedColumnChecked(rowIndex))
                {
                    dr = gridViewButtInfo.GetDataRow(rowIndex);
                    if (dr.RowState == DataRowState.Added)
                    {
                        instable.Rows.Add(dr.ItemArray);
                    }
                    else if (dr.RowState == DataRowState.Modified)
                    {
                        updtable.Rows.Add(dr.ItemArray);
                    }
                }
            }

            DataSet inBlock = new DataSet();
            if (instable != null && instable.Rows.Count > 0)
            {
                for (int i = 0; i < instable.Rows.Count; i++)
                {
                    instable.Rows[i]["fname"] = formName;
                    instable.Rows[i]["appname"] = CConstString.AppName;
                }
                instable.TableName = "INSERT_BLOCK";
                inBlock.Tables.Add(instable);

            }
            if (deltable != null && deltable.Rows.Count > 0)
            {
                deltable.RejectChanges();
                deltable.TableName = "DELETE_BLOCK";
                inBlock.Tables.Add(deltable);
            }
            if (updtable != null && updtable.Rows.Count > 0)
            {
                for (int i = 0; i < updtable.Rows.Count; i++)
                {
                    updtable.Rows[i]["fname"] = formName;
                    updtable.Rows[i]["appname"] = CConstString.AppName;
                }
                updtable.TableName = "UPDATE_BLOCK";
                inBlock.Tables.Add(updtable);
            }
            if (inBlock.Tables.Count > 0)
            {
                string msg = DbResource.SaveButtonInfo(inBlock, CConstString.ConnectName);
                MessageBox.Show(msg, "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            QueryButton();
            return true;
        }
        #endregion




        #region Grid下方分页条按钮事件
        void FormInfoEmbeddedNavigator_ButtonClick(object sender, NavigatorButtonClickEventArgs e)
        {
            gridViewFormInfo.PostEditor();
            switch (e.Button.ImageIndex)
            {
                case SAVE:
                    if (isChange(fgDevGridFormInfo))
                    {
                        //检查数据
                        if (!formCheck())
                        {
                            break;
                        }
                        //操作数据库
                        if (!SaveFormInfo())
                        {
                            break;
                        }
                        QueryForm();
                    }
                    break;
                case DISCARD:
                    QueryForm();
                    break;
                Default:
                    break;
            }
        }
        void ButtInfoEmbeddedNavigator_ButtonClick(object sender, NavigatorButtonClickEventArgs e)
        {
            fgDevGridButtInfo.Parent.Focus();
            switch (e.Button.ImageIndex)
            {
                case SAVE:
                    if (isChange(fgDevGridButtInfo))
                    {
                        //检查数据
                        if (!btnCheck())
                        {
                            break;
                        }
                        //操作数据库
                        if (!SaveButtInfo())
                        {
                            break;
                        }
                        QueryButton();
                    }
                    break;
                case DISCARD:
                    QueryButton();
                    break;
                default:
                    break;
            }
        }
        #endregion

        private void Form1_Load(object sender, EventArgs e)
        {
            InitDevGridCustomButtons();
            SetPageState(false);
            //QueryForm();
        }

        #region 画面Grid焦点行改变 事件(重新查询所含按钮)
        private void gridViewFormInfo_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            if (gridViewFormInfo.FocusedRowHandle >= 0)
            {
                if (gridViewFormInfo.GetFocusedRowCellValue("NAME") == null)
                    return;
                formName = gridViewFormInfo.GetFocusedRowCellValue("NAME").ToString();
                QueryButton();
            }
        }
        #endregion

        #region 查询按钮事件
        private void btnQuery_Click(object sender, EventArgs e)
        {
            QueryForm();
        }
        #endregion

        #region 工具栏 按钮事件(编辑,保存,取消)
        private void barButtonItemEdit_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            SetPageState(true);
        }

        private void barButtonItemSave_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            try
            {
                SaveData();
            }
            catch (Exception ex)
            {
                EF.EFMessageBox.Show(ex.Message);
            }
        }

        private void barButtonItemCancel_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            try
            {
                CancelEdit();
            }
            catch (Exception ex)
            {
                EF.EFMessageBox.Show(ex.Message);
            }
        }
        #endregion

    }
}
