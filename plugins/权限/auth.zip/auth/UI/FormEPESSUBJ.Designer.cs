﻿namespace EP
{
    partial class FormEPESSUBJ
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormEPESSUBJ));
            this.splitContainerControl1 = new DevExpress.XtraEditors.SplitContainerControl();
            this.xtraTabControl1 = new DevExpress.XtraTab.XtraTabControl();
            this.xtraTabPageGroup = new DevExpress.XtraTab.XtraTabPage();
            this.tableLayoutPanelGroup = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanelGroupCondition = new System.Windows.Forms.TableLayoutPanel();
            this.lblGroupName = new DevExpress.XtraEditors.LabelControl();
            this.fgtGroupName = new DevExpress.XtraEditors.TextEdit();
            this.lblGroupAdmin = new DevExpress.XtraEditors.LabelControl();
            this.fgtGroupAdmin = new DevExpress.XtraEditors.TextEdit();
            this.fgButtonQryGrp = new DevExpress.XtraEditors.SimpleButton();
            this.fgDevGridGroupInfo = new EF.EFDevGrid();
            this.tESGROUPINFOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSetEPESSUBJ = new EP.DataSetEPESSUBJ();
            this.gridViewGroupInfo = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colNAME = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colGROUPDESCRIPTION = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colADMINUSERNAME1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repstryItemGroupBtnEditAdmin1 = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.colADMINUSERNAME2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repstryItemGroupBtnEditAdmin2 = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.colAPPNAME = new DevExpress.XtraGrid.Columns.GridColumn();
            this.barManager1 = new DevExpress.XtraBars.BarManager(this.components);
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.imageCollection1 = new DevExpress.Utils.ImageCollection(this.components);
            this.barBtnItemDeleteUser = new DevExpress.XtraBars.BarButtonItem();
            this.repositoryItemLookUpEditAdmin1 = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.repositoryItemLookUpEditAdmin2 = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.xtraTabPageUser = new DevExpress.XtraTab.XtraTabPage();
            this.tableLayoutPanelUser = new System.Windows.Forms.TableLayoutPanel();
            this.fgDevGridUserInfo = new EF.EFDevGrid();
            this.tESUSERINFOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gridViewUserInfo = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colID1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colENAME = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colCNAME = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colISENABLE = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repstryItemComboBoxUserIsEnable = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.colDEPTID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemLookUpEditDeptNo = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.colDEPT_ENAME = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemLookUpEditDeptName = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.colDEPT_CNAME = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colPASSWD_PERIOD = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colTIMETIRED = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repstryItemComboBoxUserDeptName = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.repstryItemLookUpEditUserDeptNo = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.tableLayoutPanelUserCondition = new System.Windows.Forms.TableLayoutPanel();
            this.lblEname = new DevExpress.XtraEditors.LabelControl();
            this.fgDevComboBoxEditDept = new DevExpress.XtraEditors.ComboBoxEdit();
            this.fgtEname = new DevExpress.XtraEditors.TextEdit();
            this.fgButtonUserConfig = new DevExpress.XtraEditors.SimpleButton();
            this.fgButtonQryUsr = new DevExpress.XtraEditors.SimpleButton();
            this.lblCname = new DevExpress.XtraEditors.LabelControl();
            this.fgtCname = new DevExpress.XtraEditors.TextEdit();
            this.fgLabel1 = new DevExpress.XtraEditors.LabelControl();
            this.xtraTabPageDept = new DevExpress.XtraTab.XtraTabPage();
            this.tableLayoutPanelDept = new System.Windows.Forms.TableLayoutPanel();
            this.fgDevGridDeptInfo = new EF.EFDevGrid();
            this.tESDEPTINFOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gridViewDeptInfo = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colID2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colENAME1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colCNAME1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colFDEPARTMENT = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colDEPART_LEVEL = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colDEPT_ADMIN1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemDeptBtnEditAdmin1 = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.colDEPT_ADMIN2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemDeptBtnEditAdmin2 = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.tableLayoutPanelDeptCondition = new System.Windows.Forms.TableLayoutPanel();
            this.lblDeptEname = new DevExpress.XtraEditors.LabelControl();
            this.fgtDeptEname = new DevExpress.XtraEditors.TextEdit();
            this.lblDeptCname = new DevExpress.XtraEditors.LabelControl();
            this.fgButtonQryDept = new DevExpress.XtraEditors.SimpleButton();
            this.fgtDetpCname = new DevExpress.XtraEditors.TextEdit();
            this.fgGroupBox1 = new DevExpress.XtraEditors.GroupControl();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.fgLabel3 = new DevExpress.XtraEditors.LabelControl();
            this.combDept = new DevExpress.XtraEditors.ComboBoxEdit();
            this.treeListMain = new DevExpress.XtraTreeList.TreeList();
            this.treeListColumn1 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.treeListColumn2 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemCheckEdit4 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemCheckEdit6 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemCheckEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemCheckEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.fgLabel2 = new DevExpress.XtraEditors.LabelControl();
            this.fgLabelComp = new DevExpress.XtraEditors.LabelControl();
            this.popupMenuTreeList = new DevExpress.XtraBars.PopupMenu(this.components);
            this.fgButtonFocus = new DevExpress.XtraEditors.SimpleButton();
            this.imageListGridPageBar = new System.Windows.Forms.ImageList(this.components);
            this.fgDevComboBoxEditComp = new DevExpress.XtraEditors.ComboBoxEdit();
            this.fgDevComboBoxEditApp = new DevExpress.XtraEditors.ComboBoxEdit();
            this.fgGroupBox2 = new DevExpress.XtraEditors.GroupControl();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanelAll = new System.Windows.Forms.TableLayoutPanel();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).BeginInit();
            this.splitContainerControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).BeginInit();
            this.xtraTabControl1.SuspendLayout();
            this.xtraTabPageGroup.SuspendLayout();
            this.tableLayoutPanelGroup.SuspendLayout();
            this.tableLayoutPanelGroupCondition.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgtGroupName.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgtGroupAdmin.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgDevGridGroupInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tESGROUPINFOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetEPESSUBJ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewGroupInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repstryItemGroupBtnEditAdmin1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repstryItemGroupBtnEditAdmin2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEditAdmin1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEditAdmin2)).BeginInit();
            this.xtraTabPageUser.SuspendLayout();
            this.tableLayoutPanelUser.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgDevGridUserInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tESUSERINFOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewUserInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repstryItemComboBoxUserIsEnable)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEditDeptNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEditDeptName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repstryItemComboBoxUserDeptName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repstryItemLookUpEditUserDeptNo)).BeginInit();
            this.tableLayoutPanelUserCondition.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgDevComboBoxEditDept.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgtEname.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgtCname.Properties)).BeginInit();
            this.xtraTabPageDept.SuspendLayout();
            this.tableLayoutPanelDept.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgDevGridDeptInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tESDEPTINFOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewDeptInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDeptBtnEditAdmin1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDeptBtnEditAdmin2)).BeginInit();
            this.tableLayoutPanelDeptCondition.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgtDeptEname.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgtDetpCname.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgGroupBox1)).BeginInit();
            this.fgGroupBox1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.combDept.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.treeListMain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.popupMenuTreeList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgDevComboBoxEditComp.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgDevComboBoxEditApp.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgGroupBox2)).BeginInit();
            this.fgGroupBox2.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanelAll.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainerControl1
            // 
            resources.ApplyResources(this.splitContainerControl1, "splitContainerControl1");
            this.splitContainerControl1.Name = "splitContainerControl1";
            this.splitContainerControl1.Panel1.Controls.Add(this.xtraTabControl1);
            resources.ApplyResources(this.splitContainerControl1.Panel1, "splitContainerControl1.Panel1");
            this.splitContainerControl1.Panel2.Controls.Add(this.fgGroupBox1);
            resources.ApplyResources(this.splitContainerControl1.Panel2, "splitContainerControl1.Panel2");
            this.splitContainerControl1.SplitterPosition = 589;
            // 
            // xtraTabControl1
            // 
            resources.ApplyResources(this.xtraTabControl1, "xtraTabControl1");
            this.xtraTabControl1.Name = "xtraTabControl1";
            this.xtraTabControl1.SelectedTabPage = this.xtraTabPageGroup;
            this.xtraTabControl1.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.xtraTabPageGroup,
            this.xtraTabPageUser,
            this.xtraTabPageDept});
            this.xtraTabControl1.SelectedPageChanged += new DevExpress.XtraTab.TabPageChangedEventHandler(this.xtraTabControl1_SelectedPageChanged);
            // 
            // xtraTabPageGroup
            // 
            this.xtraTabPageGroup.Controls.Add(this.tableLayoutPanelGroup);
            this.xtraTabPageGroup.Name = "xtraTabPageGroup";
            resources.ApplyResources(this.xtraTabPageGroup, "xtraTabPageGroup");
            // 
            // tableLayoutPanelGroup
            // 
            resources.ApplyResources(this.tableLayoutPanelGroup, "tableLayoutPanelGroup");
            this.tableLayoutPanelGroup.Controls.Add(this.tableLayoutPanelGroupCondition, 0, 0);
            this.tableLayoutPanelGroup.Controls.Add(this.fgDevGridGroupInfo, 0, 1);
            this.tableLayoutPanelGroup.Name = "tableLayoutPanelGroup";
            // 
            // tableLayoutPanelGroupCondition
            // 
            resources.ApplyResources(this.tableLayoutPanelGroupCondition, "tableLayoutPanelGroupCondition");
            this.tableLayoutPanelGroupCondition.Controls.Add(this.lblGroupName, 0, 0);
            this.tableLayoutPanelGroupCondition.Controls.Add(this.fgtGroupName, 1, 0);
            this.tableLayoutPanelGroupCondition.Controls.Add(this.lblGroupAdmin, 2, 0);
            this.tableLayoutPanelGroupCondition.Controls.Add(this.fgtGroupAdmin, 3, 0);
            this.tableLayoutPanelGroupCondition.Controls.Add(this.fgButtonQryGrp, 4, 0);
            this.tableLayoutPanelGroupCondition.Name = "tableLayoutPanelGroupCondition";
            // 
            // lblGroupName
            // 
            resources.ApplyResources(this.lblGroupName, "lblGroupName");
            this.lblGroupName.Appearance.Options.UseTextOptions = true;
            this.lblGroupName.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.lblGroupName.Name = "lblGroupName";
            // 
            // fgtGroupName
            // 
            resources.ApplyResources(this.fgtGroupName, "fgtGroupName");
            this.fgtGroupName.Name = "fgtGroupName";
            // 
            // lblGroupAdmin
            // 
            resources.ApplyResources(this.lblGroupAdmin, "lblGroupAdmin");
            this.lblGroupAdmin.Appearance.Options.UseTextOptions = true;
            this.lblGroupAdmin.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.lblGroupAdmin.Name = "lblGroupAdmin";
            // 
            // fgtGroupAdmin
            // 
            resources.ApplyResources(this.fgtGroupAdmin, "fgtGroupAdmin");
            this.fgtGroupAdmin.Name = "fgtGroupAdmin";
            // 
            // fgButtonQryGrp
            // 
            resources.ApplyResources(this.fgButtonQryGrp, "fgButtonQryGrp");
            this.fgButtonQryGrp.Name = "fgButtonQryGrp";
            this.fgButtonQryGrp.Click += new System.EventHandler(this.fgButtonQryGrp_Click);
            // 
            // fgDevGridGroupInfo
            // 
            this.fgDevGridGroupInfo.DataSource = this.tESGROUPINFOBindingSource;
            resources.ApplyResources(this.fgDevGridGroupInfo, "fgDevGridGroupInfo");
            this.fgDevGridGroupInfo.IsUseCustomPageBar = true;
            this.fgDevGridGroupInfo.MainView = this.gridViewGroupInfo;
            this.fgDevGridGroupInfo.MenuManager = this.barManager1;
            this.fgDevGridGroupInfo.Name = "fgDevGridGroupInfo";
            this.fgDevGridGroupInfo.RecordCountMessage = "Record {0} of {1}";
            this.fgDevGridGroupInfo.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemLookUpEditAdmin1,
            this.repositoryItemLookUpEditAdmin2,
            this.repstryItemGroupBtnEditAdmin1,
            this.repstryItemGroupBtnEditAdmin2});
            this.fgDevGridGroupInfo.ShowAddCopyRowButton = true;
            this.fgDevGridGroupInfo.ShowAddRowButton = true;
            this.fgDevGridGroupInfo.ShowDeleteRowButton = true;
            this.fgDevGridGroupInfo.ShowFilterButton = false;
            this.fgDevGridGroupInfo.ShowGroupButton = false;
            this.fgDevGridGroupInfo.ShowPageButton = false;
            this.fgDevGridGroupInfo.ShowRefreshButton = false;
            this.fgDevGridGroupInfo.ShowSelectionColumn = true;
            this.fgDevGridGroupInfo.UseEmbeddedNavigator = true;
            this.fgDevGridGroupInfo.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewGroupInfo});
            this.fgDevGridGroupInfo.EF_GridBar_AddRow_Event += new EF.EFDevGrid.EFGridBarClickEvent(this.fgDevGridGroupInfo_EF_GridBar_AddRow_Event);
            this.fgDevGridGroupInfo.DoubleClick += new System.EventHandler(this.fgDevGridGroupInfo_DoubleClick);
            // 
            // tESGROUPINFOBindingSource
            // 
            this.tESGROUPINFOBindingSource.DataMember = "TESGROUPINFO";
            this.tESGROUPINFOBindingSource.DataSource = this.dataSetEPESSUBJ;
            // 
            // dataSetEPESSUBJ
            // 
            this.dataSetEPESSUBJ.DataSetName = "DataSetEPESSUBJ";
            this.dataSetEPESSUBJ.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // gridViewGroupInfo
            // 
            this.gridViewGroupInfo.Appearance.Empty.BackColor = System.Drawing.Color.Transparent;
            this.gridViewGroupInfo.Appearance.Empty.Options.UseBackColor = true;
            this.gridViewGroupInfo.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colID,
            this.colNAME,
            this.colGROUPDESCRIPTION,
            this.colADMINUSERNAME1,
            this.colADMINUSERNAME2,
            this.colAPPNAME});
            this.gridViewGroupInfo.FixedLineWidth = 1;
            this.gridViewGroupInfo.GridControl = this.fgDevGridGroupInfo;
            this.gridViewGroupInfo.IndicatorWidth = 35;
            this.gridViewGroupInfo.Name = "gridViewGroupInfo";
            this.gridViewGroupInfo.OptionsView.ColumnAutoWidth = false;
            this.gridViewGroupInfo.OptionsView.EnableAppearanceEvenRow = true;
            this.gridViewGroupInfo.OptionsView.EnableAppearanceOddRow = true;
            this.gridViewGroupInfo.OptionsView.ShowGroupPanel = false;
            this.gridViewGroupInfo.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.gridViewGroupInfo_FocusedRowChanged);
            this.gridViewGroupInfo.CellValueChanging += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.gridViewGroupInfo_CellValueChanging);
            this.gridViewGroupInfo.MouseMove += new System.Windows.Forms.MouseEventHandler(this.gridViewGroupInfo_MouseMove);
            // 
            // colID
            // 
            this.colID.FieldName = "ID";
            this.colID.Name = "colID";
            // 
            // colNAME
            // 
            resources.ApplyResources(this.colNAME, "colNAME");
            this.colNAME.FieldName = "NAME";
            this.colNAME.Name = "colNAME";
            this.colNAME.OptionsColumn.AllowMove = false;
            this.colNAME.OptionsColumn.FixedWidth = true;
            this.colNAME.OptionsFilter.AllowAutoFilter = false;
            this.colNAME.OptionsFilter.AllowFilter = false;
            // 
            // colGROUPDESCRIPTION
            // 
            resources.ApplyResources(this.colGROUPDESCRIPTION, "colGROUPDESCRIPTION");
            this.colGROUPDESCRIPTION.FieldName = "GROUPDESCRIPTION";
            this.colGROUPDESCRIPTION.Name = "colGROUPDESCRIPTION";
            this.colGROUPDESCRIPTION.OptionsColumn.AllowMove = false;
            this.colGROUPDESCRIPTION.OptionsColumn.FixedWidth = true;
            this.colGROUPDESCRIPTION.OptionsFilter.AllowAutoFilter = false;
            this.colGROUPDESCRIPTION.OptionsFilter.AllowFilter = false;
            // 
            // colADMINUSERNAME1
            // 
            resources.ApplyResources(this.colADMINUSERNAME1, "colADMINUSERNAME1");
            this.colADMINUSERNAME1.ColumnEdit = this.repstryItemGroupBtnEditAdmin1;
            this.colADMINUSERNAME1.FieldName = "ADMINUSERNAME1";
            this.colADMINUSERNAME1.Name = "colADMINUSERNAME1";
            this.colADMINUSERNAME1.OptionsColumn.AllowMove = false;
            this.colADMINUSERNAME1.OptionsColumn.FixedWidth = true;
            this.colADMINUSERNAME1.OptionsFilter.AllowAutoFilter = false;
            this.colADMINUSERNAME1.OptionsFilter.AllowFilter = false;
            // 
            // repstryItemGroupBtnEditAdmin1
            // 
            resources.ApplyResources(this.repstryItemGroupBtnEditAdmin1, "repstryItemGroupBtnEditAdmin1");
            this.repstryItemGroupBtnEditAdmin1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repstryItemGroupBtnEditAdmin1.Name = "repstryItemGroupBtnEditAdmin1";
            this.repstryItemGroupBtnEditAdmin1.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repstryItemGroupBtnEditAdmin1_ButtonClick);
            // 
            // colADMINUSERNAME2
            // 
            resources.ApplyResources(this.colADMINUSERNAME2, "colADMINUSERNAME2");
            this.colADMINUSERNAME2.ColumnEdit = this.repstryItemGroupBtnEditAdmin2;
            this.colADMINUSERNAME2.FieldName = "ADMINUSERNAME2";
            this.colADMINUSERNAME2.Name = "colADMINUSERNAME2";
            this.colADMINUSERNAME2.OptionsColumn.AllowMove = false;
            this.colADMINUSERNAME2.OptionsColumn.FixedWidth = true;
            this.colADMINUSERNAME2.OptionsFilter.AllowAutoFilter = false;
            this.colADMINUSERNAME2.OptionsFilter.AllowFilter = false;
            // 
            // repstryItemGroupBtnEditAdmin2
            // 
            resources.ApplyResources(this.repstryItemGroupBtnEditAdmin2, "repstryItemGroupBtnEditAdmin2");
            this.repstryItemGroupBtnEditAdmin2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repstryItemGroupBtnEditAdmin2.Name = "repstryItemGroupBtnEditAdmin2";
            this.repstryItemGroupBtnEditAdmin2.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repstryItemGroupBtnEditAdmin2_ButtonClick);
            // 
            // colAPPNAME
            // 
            resources.ApplyResources(this.colAPPNAME, "colAPPNAME");
            this.colAPPNAME.FieldName = "APPNAME";
            this.colAPPNAME.Name = "colAPPNAME";
            this.colAPPNAME.OptionsColumn.AllowMove = false;
            this.colAPPNAME.OptionsColumn.FixedWidth = true;
            this.colAPPNAME.OptionsFilter.AllowAutoFilter = false;
            this.colAPPNAME.OptionsFilter.AllowFilter = false;
            // 
            // barManager1
            // 
            this.barManager1.Categories.AddRange(new DevExpress.XtraBars.BarManagerCategory[] {
            ((DevExpress.XtraBars.BarManagerCategory)(resources.GetObject("barManager1.Categories")))});
            this.barManager1.DockControls.Add(this.barDockControlTop);
            this.barManager1.DockControls.Add(this.barDockControlBottom);
            this.barManager1.DockControls.Add(this.barDockControlLeft);
            this.barManager1.DockControls.Add(this.barDockControlRight);
            this.barManager1.Form = this;
            this.barManager1.Images = this.imageCollection1;
            this.barManager1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.barBtnItemDeleteUser});
            this.barManager1.MaxItemId = 84;
            // 
            // imageCollection1
            // 
            this.imageCollection1.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("imageCollection1.ImageStream")));
            this.imageCollection1.Images.SetKeyName(0, "GROUP");
            this.imageCollection1.Images.SetKeyName(1, "GROUP_GRAY");
            this.imageCollection1.Images.SetKeyName(2, "USER");
            this.imageCollection1.Images.SetKeyName(3, "DEPT");
            this.imageCollection1.Images.SetKeyName(4, "DELETE.png");
            // 
            // barBtnItemDeleteUser
            // 
            resources.ApplyResources(this.barBtnItemDeleteUser, "barBtnItemDeleteUser");
            this.barBtnItemDeleteUser.CategoryGuid = new System.Guid("d81acbd1-0c9d-467d-bb41-e5327adff930");
            this.barBtnItemDeleteUser.Id = 1;
            this.barBtnItemDeleteUser.ImageIndex = 4;
            this.barBtnItemDeleteUser.Name = "barBtnItemDeleteUser";
            this.barBtnItemDeleteUser.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItemDeleteUser_ItemClick);
            // 
            // repositoryItemLookUpEditAdmin1
            // 
            resources.ApplyResources(this.repositoryItemLookUpEditAdmin1, "repositoryItemLookUpEditAdmin1");
            this.repositoryItemLookUpEditAdmin1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("repositoryItemLookUpEditAdmin1.Buttons"))))});
            this.repositoryItemLookUpEditAdmin1.Name = "repositoryItemLookUpEditAdmin1";
            this.repositoryItemLookUpEditAdmin1.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.repositoryItemLookUpEditAdmin1.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemLookUpEditAdmin1_ButtonClick);
            // 
            // repositoryItemLookUpEditAdmin2
            // 
            resources.ApplyResources(this.repositoryItemLookUpEditAdmin2, "repositoryItemLookUpEditAdmin2");
            this.repositoryItemLookUpEditAdmin2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("repositoryItemLookUpEditAdmin2.Buttons"))))});
            this.repositoryItemLookUpEditAdmin2.Name = "repositoryItemLookUpEditAdmin2";
            this.repositoryItemLookUpEditAdmin2.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            // 
            // xtraTabPageUser
            // 
            this.xtraTabPageUser.Controls.Add(this.tableLayoutPanelUser);
            this.xtraTabPageUser.Name = "xtraTabPageUser";
            resources.ApplyResources(this.xtraTabPageUser, "xtraTabPageUser");
            // 
            // tableLayoutPanelUser
            // 
            resources.ApplyResources(this.tableLayoutPanelUser, "tableLayoutPanelUser");
            this.tableLayoutPanelUser.Controls.Add(this.fgDevGridUserInfo, 0, 1);
            this.tableLayoutPanelUser.Controls.Add(this.tableLayoutPanelUserCondition, 0, 0);
            this.tableLayoutPanelUser.Name = "tableLayoutPanelUser";
            // 
            // fgDevGridUserInfo
            // 
            this.fgDevGridUserInfo.DataSource = this.tESUSERINFOBindingSource;
            resources.ApplyResources(this.fgDevGridUserInfo, "fgDevGridUserInfo");
            this.fgDevGridUserInfo.IsUseCustomPageBar = true;
            this.fgDevGridUserInfo.MainView = this.gridViewUserInfo;
            this.fgDevGridUserInfo.MenuManager = this.barManager1;
            this.fgDevGridUserInfo.Name = "fgDevGridUserInfo";
            this.fgDevGridUserInfo.RecordCountMessage = "{0}/{1}";
            this.fgDevGridUserInfo.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repstryItemComboBoxUserIsEnable,
            this.repstryItemComboBoxUserDeptName,
            this.repstryItemLookUpEditUserDeptNo,
            this.repositoryItemLookUpEditDeptNo,
            this.repositoryItemLookUpEditDeptName});
            this.fgDevGridUserInfo.ShowFilterButton = false;
            this.fgDevGridUserInfo.ShowGroupButton = false;
            this.fgDevGridUserInfo.ShowPageButton = false;
            this.fgDevGridUserInfo.ShowRecordCountMessage = true;
            this.fgDevGridUserInfo.ShowRefreshButton = false;
            this.fgDevGridUserInfo.ShowSelectionColumn = true;
            this.fgDevGridUserInfo.UseEmbeddedNavigator = true;
            this.fgDevGridUserInfo.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewUserInfo});
            this.fgDevGridUserInfo.EF_GridBar_AddRow_Event += new EF.EFDevGrid.EFGridBarClickEvent(this.fgDevGridUserInfo_EF_GridBar_AddRow_Event);
            this.fgDevGridUserInfo.DoubleClick += new System.EventHandler(this.fgDevGridUserInfo_DoubleClick);
            // 
            // tESUSERINFOBindingSource
            // 
            this.tESUSERINFOBindingSource.DataMember = "TESUSERINFO";
            this.tESUSERINFOBindingSource.DataSource = this.dataSetEPESSUBJ;
            // 
            // gridViewUserInfo
            // 
            this.gridViewUserInfo.Appearance.Empty.BackColor = System.Drawing.Color.Transparent;
            this.gridViewUserInfo.Appearance.Empty.Options.UseBackColor = true;
            this.gridViewUserInfo.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colID1,
            this.colENAME,
            this.colCNAME,
            this.colISENABLE,
            this.colDEPTID,
            this.colDEPT_ENAME,
            this.colDEPT_CNAME,
            this.colPASSWD_PERIOD,
            this.colTIMETIRED});
            this.gridViewUserInfo.FixedLineWidth = 1;
            this.gridViewUserInfo.GridControl = this.fgDevGridUserInfo;
            this.gridViewUserInfo.IndicatorWidth = 35;
            this.gridViewUserInfo.Name = "gridViewUserInfo";
            this.gridViewUserInfo.OptionsView.ColumnAutoWidth = false;
            this.gridViewUserInfo.OptionsView.EnableAppearanceEvenRow = true;
            this.gridViewUserInfo.OptionsView.EnableAppearanceOddRow = true;
            this.gridViewUserInfo.OptionsView.ShowGroupPanel = false;
            this.gridViewUserInfo.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.gridViewUserInfo_FocusedRowChanged);
            this.gridViewUserInfo.CellValueChanging += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.gridViewUserInfo_CellValueChanging);
            this.gridViewUserInfo.MouseMove += new System.Windows.Forms.MouseEventHandler(this.gridViewUserInfo_MouseMove);
            // 
            // colID1
            // 
            this.colID1.FieldName = "ID";
            this.colID1.Name = "colID1";
            // 
            // colENAME
            // 
            resources.ApplyResources(this.colENAME, "colENAME");
            this.colENAME.FieldName = "ENAME";
            this.colENAME.Name = "colENAME";
            this.colENAME.OptionsColumn.AllowMove = false;
            this.colENAME.OptionsColumn.FixedWidth = true;
            this.colENAME.OptionsFilter.AllowAutoFilter = false;
            this.colENAME.OptionsFilter.AllowFilter = false;
            // 
            // colCNAME
            // 
            resources.ApplyResources(this.colCNAME, "colCNAME");
            this.colCNAME.FieldName = "CNAME";
            this.colCNAME.Name = "colCNAME";
            this.colCNAME.OptionsColumn.FixedWidth = true;
            this.colCNAME.OptionsFilter.AllowAutoFilter = false;
            this.colCNAME.OptionsFilter.AllowFilter = false;
            // 
            // colISENABLE
            // 
            resources.ApplyResources(this.colISENABLE, "colISENABLE");
            this.colISENABLE.ColumnEdit = this.repstryItemComboBoxUserIsEnable;
            this.colISENABLE.FieldName = "ISENABLE";
            this.colISENABLE.Name = "colISENABLE";
            this.colISENABLE.OptionsColumn.AllowMove = false;
            this.colISENABLE.OptionsColumn.FixedWidth = true;
            this.colISENABLE.OptionsFilter.AllowAutoFilter = false;
            this.colISENABLE.OptionsFilter.AllowFilter = false;
            // 
            // repstryItemComboBoxUserIsEnable
            // 
            resources.ApplyResources(this.repstryItemComboBoxUserIsEnable, "repstryItemComboBoxUserIsEnable");
            this.repstryItemComboBoxUserIsEnable.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("repstryItemComboBoxUserIsEnable.Buttons"))))});
            this.repstryItemComboBoxUserIsEnable.Items.AddRange(new object[] {
            resources.GetString("repstryItemComboBoxUserIsEnable.Items"),
            resources.GetString("repstryItemComboBoxUserIsEnable.Items1")});
            this.repstryItemComboBoxUserIsEnable.Name = "repstryItemComboBoxUserIsEnable";
            // 
            // colDEPTID
            // 
            resources.ApplyResources(this.colDEPTID, "colDEPTID");
            this.colDEPTID.ColumnEdit = this.repositoryItemLookUpEditDeptNo;
            this.colDEPTID.FieldName = "DEPTID";
            this.colDEPTID.Name = "colDEPTID";
            this.colDEPTID.OptionsColumn.AllowMove = false;
            this.colDEPTID.OptionsColumn.FixedWidth = true;
            this.colDEPTID.OptionsFilter.AllowAutoFilter = false;
            this.colDEPTID.OptionsFilter.AllowFilter = false;
            // 
            // repositoryItemLookUpEditDeptNo
            // 
            resources.ApplyResources(this.repositoryItemLookUpEditDeptNo, "repositoryItemLookUpEditDeptNo");
            this.repositoryItemLookUpEditDeptNo.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("repositoryItemLookUpEditDeptNo.Buttons"))))});
            this.repositoryItemLookUpEditDeptNo.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo(resources.GetString("repositoryItemLookUpEditDeptNo.Columns"), resources.GetString("repositoryItemLookUpEditDeptNo.Columns1")),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo(resources.GetString("repositoryItemLookUpEditDeptNo.Columns2"), resources.GetString("repositoryItemLookUpEditDeptNo.Columns3")),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo(resources.GetString("repositoryItemLookUpEditDeptNo.Columns4"), resources.GetString("repositoryItemLookUpEditDeptNo.Columns5"))});
            this.repositoryItemLookUpEditDeptNo.HighlightedItemStyle = DevExpress.XtraEditors.HighlightStyle.Skinned;
            this.repositoryItemLookUpEditDeptNo.Name = "repositoryItemLookUpEditDeptNo";
            this.repositoryItemLookUpEditDeptNo.EditValueChanged += new System.EventHandler(this.repositoryItemLookUpEditDeptNo_EditValueChanged);
            // 
            // colDEPT_ENAME
            // 
            resources.ApplyResources(this.colDEPT_ENAME, "colDEPT_ENAME");
            this.colDEPT_ENAME.ColumnEdit = this.repositoryItemLookUpEditDeptName;
            this.colDEPT_ENAME.FieldName = "DEPT_ENAME";
            this.colDEPT_ENAME.Name = "colDEPT_ENAME";
            this.colDEPT_ENAME.OptionsColumn.AllowMove = false;
            this.colDEPT_ENAME.OptionsColumn.FixedWidth = true;
            this.colDEPT_ENAME.OptionsFilter.AllowAutoFilter = false;
            this.colDEPT_ENAME.OptionsFilter.AllowFilter = false;
            // 
            // repositoryItemLookUpEditDeptName
            // 
            resources.ApplyResources(this.repositoryItemLookUpEditDeptName, "repositoryItemLookUpEditDeptName");
            this.repositoryItemLookUpEditDeptName.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("repositoryItemLookUpEditDeptName.Buttons"))))});
            this.repositoryItemLookUpEditDeptName.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo(resources.GetString("repositoryItemLookUpEditDeptName.Columns"), resources.GetString("repositoryItemLookUpEditDeptName.Columns1"), ((int)(resources.GetObject("repositoryItemLookUpEditDeptName.Columns2"))), ((DevExpress.Utils.FormatType)(resources.GetObject("repositoryItemLookUpEditDeptName.Columns3"))), resources.GetString("repositoryItemLookUpEditDeptName.Columns4"), ((bool)(resources.GetObject("repositoryItemLookUpEditDeptName.Columns5"))), ((DevExpress.Utils.HorzAlignment)(resources.GetObject("repositoryItemLookUpEditDeptName.Columns6")))),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo(resources.GetString("repositoryItemLookUpEditDeptName.Columns7"), resources.GetString("repositoryItemLookUpEditDeptName.Columns8")),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo(resources.GetString("repositoryItemLookUpEditDeptName.Columns9"), resources.GetString("repositoryItemLookUpEditDeptName.Columns10"))});
            this.repositoryItemLookUpEditDeptName.Name = "repositoryItemLookUpEditDeptName";
            this.repositoryItemLookUpEditDeptName.EditValueChanged += new System.EventHandler(this.repositoryItemLookUpEditDeptName_EditValueChanged);
            // 
            // colDEPT_CNAME
            // 
            resources.ApplyResources(this.colDEPT_CNAME, "colDEPT_CNAME");
            this.colDEPT_CNAME.FieldName = "DEPT_CNAME";
            this.colDEPT_CNAME.Name = "colDEPT_CNAME";
            this.colDEPT_CNAME.OptionsColumn.AllowEdit = false;
            this.colDEPT_CNAME.OptionsColumn.AllowMove = false;
            this.colDEPT_CNAME.OptionsColumn.FixedWidth = true;
            // 
            // colPASSWD_PERIOD
            // 
            resources.ApplyResources(this.colPASSWD_PERIOD, "colPASSWD_PERIOD");
            this.colPASSWD_PERIOD.FieldName = "PASSWD_PERIOD";
            this.colPASSWD_PERIOD.Name = "colPASSWD_PERIOD";
            this.colPASSWD_PERIOD.OptionsColumn.AllowMove = false;
            this.colPASSWD_PERIOD.OptionsColumn.FixedWidth = true;
            this.colPASSWD_PERIOD.OptionsFilter.AllowAutoFilter = false;
            this.colPASSWD_PERIOD.OptionsFilter.AllowFilter = false;
            // 
            // colTIMETIRED
            // 
            resources.ApplyResources(this.colTIMETIRED, "colTIMETIRED");
            this.colTIMETIRED.FieldName = "TIMETIRED";
            this.colTIMETIRED.Name = "colTIMETIRED";
            this.colTIMETIRED.OptionsColumn.AllowEdit = false;
            this.colTIMETIRED.OptionsColumn.AllowMove = false;
            this.colTIMETIRED.OptionsColumn.FixedWidth = true;
            this.colTIMETIRED.OptionsFilter.AllowAutoFilter = false;
            this.colTIMETIRED.OptionsFilter.AllowFilter = false;
            // 
            // repstryItemComboBoxUserDeptName
            // 
            resources.ApplyResources(this.repstryItemComboBoxUserDeptName, "repstryItemComboBoxUserDeptName");
            this.repstryItemComboBoxUserDeptName.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("repstryItemComboBoxUserDeptName.Buttons"))))});
            this.repstryItemComboBoxUserDeptName.Name = "repstryItemComboBoxUserDeptName";
            // 
            // repstryItemLookUpEditUserDeptNo
            // 
            resources.ApplyResources(this.repstryItemLookUpEditUserDeptNo, "repstryItemLookUpEditUserDeptNo");
            this.repstryItemLookUpEditUserDeptNo.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("repstryItemLookUpEditUserDeptNo.Buttons"))))});
            this.repstryItemLookUpEditUserDeptNo.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo(resources.GetString("repstryItemLookUpEditUserDeptNo.Columns"), resources.GetString("repstryItemLookUpEditUserDeptNo.Columns1")),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo(resources.GetString("repstryItemLookUpEditUserDeptNo.Columns2"), resources.GetString("repstryItemLookUpEditUserDeptNo.Columns3")),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo(resources.GetString("repstryItemLookUpEditUserDeptNo.Columns4"), resources.GetString("repstryItemLookUpEditUserDeptNo.Columns5"))});
            this.repstryItemLookUpEditUserDeptNo.HighlightedItemStyle = DevExpress.XtraEditors.HighlightStyle.Skinned;
            this.repstryItemLookUpEditUserDeptNo.HotTrackItems = false;
            this.repstryItemLookUpEditUserDeptNo.ImmediatePopup = true;
            this.repstryItemLookUpEditUserDeptNo.Name = "repstryItemLookUpEditUserDeptNo";
            this.repstryItemLookUpEditUserDeptNo.EditValueChanged += new System.EventHandler(this.repstryItemLookUpEditUserDeptNo_EditValueChanged);
            // 
            // tableLayoutPanelUserCondition
            // 
            resources.ApplyResources(this.tableLayoutPanelUserCondition, "tableLayoutPanelUserCondition");
            this.tableLayoutPanelUserCondition.Controls.Add(this.lblEname, 0, 0);
            this.tableLayoutPanelUserCondition.Controls.Add(this.fgDevComboBoxEditDept, 5, 0);
            this.tableLayoutPanelUserCondition.Controls.Add(this.fgtEname, 1, 0);
            this.tableLayoutPanelUserCondition.Controls.Add(this.fgButtonUserConfig, 7, 0);
            this.tableLayoutPanelUserCondition.Controls.Add(this.fgButtonQryUsr, 6, 0);
            this.tableLayoutPanelUserCondition.Controls.Add(this.lblCname, 2, 0);
            this.tableLayoutPanelUserCondition.Controls.Add(this.fgtCname, 3, 0);
            this.tableLayoutPanelUserCondition.Controls.Add(this.fgLabel1, 4, 0);
            this.tableLayoutPanelUserCondition.Name = "tableLayoutPanelUserCondition";
            // 
            // lblEname
            // 
            resources.ApplyResources(this.lblEname, "lblEname");
            this.lblEname.Name = "lblEname";
            // 
            // fgDevComboBoxEditDept
            // 
            resources.ApplyResources(this.fgDevComboBoxEditDept, "fgDevComboBoxEditDept");
            this.fgDevComboBoxEditDept.MenuManager = this.barManager1;
            this.fgDevComboBoxEditDept.Name = "fgDevComboBoxEditDept";
            this.fgDevComboBoxEditDept.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("fgDevComboBoxEditDept.Properties.Buttons"))))});
            this.fgDevComboBoxEditDept.Properties.HighlightedItemStyle = DevExpress.XtraEditors.HighlightStyle.Skinned;
            this.fgDevComboBoxEditDept.Properties.PopupSizeable = true;
            this.fgDevComboBoxEditDept.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            // 
            // fgtEname
            // 
            resources.ApplyResources(this.fgtEname, "fgtEname");
            this.fgtEname.Name = "fgtEname";
            // 
            // fgButtonUserConfig
            // 
            this.fgButtonUserConfig.Image = global::EP.Properties.Resources._lock;
            this.fgButtonUserConfig.ImageList = this.imageCollection1;
            resources.ApplyResources(this.fgButtonUserConfig, "fgButtonUserConfig");
            this.fgButtonUserConfig.Name = "fgButtonUserConfig";
            this.fgButtonUserConfig.Click += new System.EventHandler(this.fgButtonUserConfig_Click);
            // 
            // fgButtonQryUsr
            // 
            resources.ApplyResources(this.fgButtonQryUsr, "fgButtonQryUsr");
            this.fgButtonQryUsr.Name = "fgButtonQryUsr";
            this.fgButtonQryUsr.Click += new System.EventHandler(this.fgButtonQryUsr_Click);
            // 
            // lblCname
            // 
            resources.ApplyResources(this.lblCname, "lblCname");
            this.lblCname.Name = "lblCname";
            // 
            // fgtCname
            // 
            resources.ApplyResources(this.fgtCname, "fgtCname");
            this.fgtCname.Name = "fgtCname";
            // 
            // fgLabel1
            // 
            resources.ApplyResources(this.fgLabel1, "fgLabel1");
            this.fgLabel1.Name = "fgLabel1";
            // 
            // xtraTabPageDept
            // 
            this.xtraTabPageDept.Controls.Add(this.tableLayoutPanelDept);
            this.xtraTabPageDept.Name = "xtraTabPageDept";
            resources.ApplyResources(this.xtraTabPageDept, "xtraTabPageDept");
            // 
            // tableLayoutPanelDept
            // 
            resources.ApplyResources(this.tableLayoutPanelDept, "tableLayoutPanelDept");
            this.tableLayoutPanelDept.Controls.Add(this.fgDevGridDeptInfo, 0, 1);
            this.tableLayoutPanelDept.Controls.Add(this.tableLayoutPanelDeptCondition, 0, 0);
            this.tableLayoutPanelDept.Name = "tableLayoutPanelDept";
            // 
            // fgDevGridDeptInfo
            // 
            this.fgDevGridDeptInfo.DataSource = this.tESDEPTINFOBindingSource;
            resources.ApplyResources(this.fgDevGridDeptInfo, "fgDevGridDeptInfo");
            this.fgDevGridDeptInfo.IsUseCustomPageBar = true;
            this.fgDevGridDeptInfo.MainView = this.gridViewDeptInfo;
            this.fgDevGridDeptInfo.MenuManager = this.barManager1;
            this.fgDevGridDeptInfo.Name = "fgDevGridDeptInfo";
            this.fgDevGridDeptInfo.RecordCountMessage = "Record {0} of {1}";
            this.fgDevGridDeptInfo.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemDeptBtnEditAdmin1,
            this.repositoryItemDeptBtnEditAdmin2});
            this.fgDevGridDeptInfo.ShowAddCopyRowButton = true;
            this.fgDevGridDeptInfo.ShowAddRowButton = true;
            this.fgDevGridDeptInfo.ShowDeleteRowButton = true;
            this.fgDevGridDeptInfo.ShowFilterButton = false;
            this.fgDevGridDeptInfo.ShowGroupButton = false;
            this.fgDevGridDeptInfo.ShowPageButton = false;
            this.fgDevGridDeptInfo.ShowRefreshButton = false;
            this.fgDevGridDeptInfo.ShowSelectionColumn = true;
            this.fgDevGridDeptInfo.UseEmbeddedNavigator = true;
            this.fgDevGridDeptInfo.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewDeptInfo});
            // 
            // tESDEPTINFOBindingSource
            // 
            this.tESDEPTINFOBindingSource.DataMember = "TESDEPTINFO";
            this.tESDEPTINFOBindingSource.DataSource = this.dataSetEPESSUBJ;
            // 
            // gridViewDeptInfo
            // 
            this.gridViewDeptInfo.Appearance.Empty.BackColor = System.Drawing.Color.Transparent;
            this.gridViewDeptInfo.Appearance.Empty.Options.UseBackColor = true;
            this.gridViewDeptInfo.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colID2,
            this.colENAME1,
            this.colCNAME1,
            this.colFDEPARTMENT,
            this.colDEPART_LEVEL,
            this.colDEPT_ADMIN1,
            this.colDEPT_ADMIN2});
            this.gridViewDeptInfo.FixedLineWidth = 1;
            this.gridViewDeptInfo.GridControl = this.fgDevGridDeptInfo;
            this.gridViewDeptInfo.IndicatorWidth = 35;
            this.gridViewDeptInfo.Name = "gridViewDeptInfo";
            this.gridViewDeptInfo.OptionsView.ColumnAutoWidth = false;
            this.gridViewDeptInfo.OptionsView.EnableAppearanceEvenRow = true;
            this.gridViewDeptInfo.OptionsView.EnableAppearanceOddRow = true;
            this.gridViewDeptInfo.OptionsView.ShowGroupPanel = false;
            this.gridViewDeptInfo.CellValueChanging += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.gridViewDeptInfo_CellValueChanging);
            // 
            // colID2
            // 
            this.colID2.FieldName = "ID";
            this.colID2.Name = "colID2";
            // 
            // colENAME1
            // 
            resources.ApplyResources(this.colENAME1, "colENAME1");
            this.colENAME1.FieldName = "ENAME";
            this.colENAME1.Name = "colENAME1";
            this.colENAME1.OptionsColumn.AllowMove = false;
            this.colENAME1.OptionsColumn.FixedWidth = true;
            this.colENAME1.OptionsFilter.AllowAutoFilter = false;
            this.colENAME1.OptionsFilter.AllowFilter = false;
            // 
            // colCNAME1
            // 
            resources.ApplyResources(this.colCNAME1, "colCNAME1");
            this.colCNAME1.FieldName = "CNAME";
            this.colCNAME1.Name = "colCNAME1";
            this.colCNAME1.OptionsColumn.AllowMove = false;
            this.colCNAME1.OptionsColumn.FixedWidth = true;
            this.colCNAME1.OptionsFilter.AllowAutoFilter = false;
            this.colCNAME1.OptionsFilter.AllowFilter = false;
            // 
            // colFDEPARTMENT
            // 
            resources.ApplyResources(this.colFDEPARTMENT, "colFDEPARTMENT");
            this.colFDEPARTMENT.FieldName = "FDEPARTMENT";
            this.colFDEPARTMENT.Name = "colFDEPARTMENT";
            this.colFDEPARTMENT.OptionsColumn.AllowMove = false;
            this.colFDEPARTMENT.OptionsColumn.FixedWidth = true;
            this.colFDEPARTMENT.OptionsFilter.AllowAutoFilter = false;
            this.colFDEPARTMENT.OptionsFilter.AllowFilter = false;
            // 
            // colDEPART_LEVEL
            // 
            resources.ApplyResources(this.colDEPART_LEVEL, "colDEPART_LEVEL");
            this.colDEPART_LEVEL.FieldName = "DEPART_LEVEL";
            this.colDEPART_LEVEL.Name = "colDEPART_LEVEL";
            this.colDEPART_LEVEL.OptionsColumn.AllowMove = false;
            this.colDEPART_LEVEL.OptionsColumn.FixedWidth = true;
            this.colDEPART_LEVEL.OptionsFilter.AllowAutoFilter = false;
            this.colDEPART_LEVEL.OptionsFilter.AllowFilter = false;
            // 
            // colDEPT_ADMIN1
            // 
            resources.ApplyResources(this.colDEPT_ADMIN1, "colDEPT_ADMIN1");
            this.colDEPT_ADMIN1.ColumnEdit = this.repositoryItemDeptBtnEditAdmin1;
            this.colDEPT_ADMIN1.FieldName = "DEPT_ADMIN1";
            this.colDEPT_ADMIN1.Name = "colDEPT_ADMIN1";
            this.colDEPT_ADMIN1.OptionsColumn.AllowMove = false;
            this.colDEPT_ADMIN1.OptionsColumn.FixedWidth = true;
            this.colDEPT_ADMIN1.OptionsFilter.AllowAutoFilter = false;
            this.colDEPT_ADMIN1.OptionsFilter.AllowFilter = false;
            // 
            // repositoryItemDeptBtnEditAdmin1
            // 
            resources.ApplyResources(this.repositoryItemDeptBtnEditAdmin1, "repositoryItemDeptBtnEditAdmin1");
            this.repositoryItemDeptBtnEditAdmin1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repositoryItemDeptBtnEditAdmin1.Name = "repositoryItemDeptBtnEditAdmin1";
            this.repositoryItemDeptBtnEditAdmin1.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemDeptBtnEditAdmin1_ButtonClick);
            // 
            // colDEPT_ADMIN2
            // 
            resources.ApplyResources(this.colDEPT_ADMIN2, "colDEPT_ADMIN2");
            this.colDEPT_ADMIN2.ColumnEdit = this.repositoryItemDeptBtnEditAdmin2;
            this.colDEPT_ADMIN2.FieldName = "DEPT_ADMIN2";
            this.colDEPT_ADMIN2.Name = "colDEPT_ADMIN2";
            this.colDEPT_ADMIN2.OptionsColumn.AllowMove = false;
            this.colDEPT_ADMIN2.OptionsColumn.FixedWidth = true;
            this.colDEPT_ADMIN2.OptionsFilter.AllowAutoFilter = false;
            this.colDEPT_ADMIN2.OptionsFilter.AllowFilter = false;
            // 
            // repositoryItemDeptBtnEditAdmin2
            // 
            resources.ApplyResources(this.repositoryItemDeptBtnEditAdmin2, "repositoryItemDeptBtnEditAdmin2");
            this.repositoryItemDeptBtnEditAdmin2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repositoryItemDeptBtnEditAdmin2.Name = "repositoryItemDeptBtnEditAdmin2";
            this.repositoryItemDeptBtnEditAdmin2.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemDeptBtnEditAdmin2_ButtonClick);
            // 
            // tableLayoutPanelDeptCondition
            // 
            resources.ApplyResources(this.tableLayoutPanelDeptCondition, "tableLayoutPanelDeptCondition");
            this.tableLayoutPanelDeptCondition.Controls.Add(this.lblDeptEname, 0, 0);
            this.tableLayoutPanelDeptCondition.Controls.Add(this.fgtDeptEname, 1, 0);
            this.tableLayoutPanelDeptCondition.Controls.Add(this.lblDeptCname, 2, 0);
            this.tableLayoutPanelDeptCondition.Controls.Add(this.fgButtonQryDept, 4, 0);
            this.tableLayoutPanelDeptCondition.Controls.Add(this.fgtDetpCname, 3, 0);
            this.tableLayoutPanelDeptCondition.Name = "tableLayoutPanelDeptCondition";
            // 
            // lblDeptEname
            // 
            resources.ApplyResources(this.lblDeptEname, "lblDeptEname");
            this.lblDeptEname.Name = "lblDeptEname";
            // 
            // fgtDeptEname
            // 
            resources.ApplyResources(this.fgtDeptEname, "fgtDeptEname");
            this.fgtDeptEname.Name = "fgtDeptEname";
            // 
            // lblDeptCname
            // 
            resources.ApplyResources(this.lblDeptCname, "lblDeptCname");
            this.lblDeptCname.Name = "lblDeptCname";
            // 
            // fgButtonQryDept
            // 
            resources.ApplyResources(this.fgButtonQryDept, "fgButtonQryDept");
            this.fgButtonQryDept.Name = "fgButtonQryDept";
            this.fgButtonQryDept.Click += new System.EventHandler(this.fgButtonQryDept_Click);
            // 
            // fgtDetpCname
            // 
            resources.ApplyResources(this.fgtDetpCname, "fgtDetpCname");
            this.fgtDetpCname.Name = "fgtDetpCname";
            // 
            // fgGroupBox1
            // 
            this.fgGroupBox1.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.fgGroupBox1.Appearance.Options.UseBackColor = true;
            this.fgGroupBox1.Controls.Add(this.tableLayoutPanel1);
            resources.ApplyResources(this.fgGroupBox1, "fgGroupBox1");
            this.fgGroupBox1.Name = "fgGroupBox1";
            // 
            // tableLayoutPanel1
            // 
            resources.ApplyResources(this.tableLayoutPanel1, "tableLayoutPanel1");
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.treeListMain, 0, 1);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            // 
            // tableLayoutPanel3
            // 
            resources.ApplyResources(this.tableLayoutPanel3, "tableLayoutPanel3");
            this.tableLayoutPanel3.Controls.Add(this.fgLabel3, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.combDept, 1, 0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            // 
            // fgLabel3
            // 
            resources.ApplyResources(this.fgLabel3, "fgLabel3");
            this.fgLabel3.Name = "fgLabel3";
            // 
            // combDept
            // 
            resources.ApplyResources(this.combDept, "combDept");
            this.combDept.MenuManager = this.barManager1;
            this.combDept.Name = "combDept";
            this.combDept.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("combDept.Properties.Buttons"))))});
            this.combDept.Properties.HighlightedItemStyle = DevExpress.XtraEditors.HighlightStyle.Skinned;
            this.combDept.Properties.PopupSizeable = true;
            this.combDept.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            this.combDept.SelectedIndexChanged += new System.EventHandler(this.combDept_SelectedIndexChanged);
            // 
            // treeListMain
            // 
            this.treeListMain.Appearance.Empty.BackColor = System.Drawing.Color.Transparent;
            this.treeListMain.Appearance.Empty.Options.UseBackColor = true;
            this.treeListMain.Appearance.EvenRow.BackColor = System.Drawing.Color.Transparent;
            this.treeListMain.Appearance.EvenRow.BackColor2 = System.Drawing.Color.Transparent;
            this.treeListMain.Appearance.EvenRow.Options.UseBackColor = true;
            this.treeListMain.Appearance.OddRow.BackColor = System.Drawing.Color.Transparent;
            this.treeListMain.Appearance.OddRow.BackColor2 = System.Drawing.Color.Transparent;
            this.treeListMain.Appearance.OddRow.Options.UseBackColor = true;
            this.treeListMain.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.treeListMain.Columns.AddRange(new DevExpress.XtraTreeList.Columns.TreeListColumn[] {
            this.treeListColumn1,
            this.treeListColumn2});
            resources.ApplyResources(this.treeListMain, "treeListMain");
            this.treeListMain.Name = "treeListMain";
            this.treeListMain.OptionsBehavior.AllowIndeterminateCheckState = true;
            this.treeListMain.OptionsBehavior.Editable = false;
            this.treeListMain.OptionsBehavior.EnableFiltering = true;
            this.treeListMain.OptionsBehavior.ExpandNodeOnDrag = false;
            this.treeListMain.OptionsBehavior.ImmediateEditor = false;
            this.treeListMain.OptionsBehavior.ResizeNodes = false;
            this.treeListMain.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.treeListMain.OptionsSelection.MultiSelect = true;
            this.treeListMain.OptionsView.EnableAppearanceEvenRow = true;
            this.treeListMain.OptionsView.EnableAppearanceOddRow = true;
            this.treeListMain.OptionsView.ShowHorzLines = false;
            this.treeListMain.OptionsView.ShowIndicator = false;
            this.treeListMain.OptionsView.ShowVertLines = false;
            this.treeListMain.SelectImageList = this.imageCollection1;
            this.treeListMain.MouseUp += new System.Windows.Forms.MouseEventHandler(this.treeListMain_MouseUp);
            this.treeListMain.SelectionChanged += new System.EventHandler(this.treeListMain_SelectionChanged);
            this.treeListMain.FocusedNodeChanged += new DevExpress.XtraTreeList.FocusedNodeChangedEventHandler(this.treeListMain_FocusedNodeChanged);
            this.treeListMain.MouseMove += new System.Windows.Forms.MouseEventHandler(this.treeListMain_MouseMove);
            this.treeListMain.DragDrop += new System.Windows.Forms.DragEventHandler(this.treeListMain_DragDrop);
            this.treeListMain.DragEnter += new System.Windows.Forms.DragEventHandler(this.treeListMain_DragEnter);
            // 
            // treeListColumn1
            // 
            resources.ApplyResources(this.treeListColumn1, "treeListColumn1");
            this.treeListColumn1.FieldName = "treeListColumn1";
            this.treeListColumn1.Name = "treeListColumn1";
            // 
            // treeListColumn2
            // 
            resources.ApplyResources(this.treeListColumn2, "treeListColumn2");
            this.treeListColumn2.FieldName = "部门";
            this.treeListColumn2.Name = "treeListColumn2";
            // 
            // repositoryItemCheckEdit1
            // 
            resources.ApplyResources(this.repositoryItemCheckEdit1, "repositoryItemCheckEdit1");
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            // 
            // repositoryItemCheckEdit4
            // 
            resources.ApplyResources(this.repositoryItemCheckEdit4, "repositoryItemCheckEdit4");
            this.repositoryItemCheckEdit4.Name = "repositoryItemCheckEdit4";
            // 
            // repositoryItemCheckEdit6
            // 
            resources.ApplyResources(this.repositoryItemCheckEdit6, "repositoryItemCheckEdit6");
            this.repositoryItemCheckEdit6.Name = "repositoryItemCheckEdit6";
            // 
            // repositoryItemCheckEdit2
            // 
            resources.ApplyResources(this.repositoryItemCheckEdit2, "repositoryItemCheckEdit2");
            this.repositoryItemCheckEdit2.Name = "repositoryItemCheckEdit2";
            // 
            // repositoryItemCheckEdit3
            // 
            resources.ApplyResources(this.repositoryItemCheckEdit3, "repositoryItemCheckEdit3");
            this.repositoryItemCheckEdit3.Name = "repositoryItemCheckEdit3";
            // 
            // fgLabel2
            // 
            this.fgLabel2.Appearance.Options.UseTextOptions = true;
            this.fgLabel2.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            resources.ApplyResources(this.fgLabel2, "fgLabel2");
            this.fgLabel2.Name = "fgLabel2";
            // 
            // fgLabelComp
            // 
            this.fgLabelComp.Appearance.Options.UseTextOptions = true;
            this.fgLabelComp.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            resources.ApplyResources(this.fgLabelComp, "fgLabelComp");
            this.fgLabelComp.Name = "fgLabelComp";
            // 
            // popupMenuTreeList
            // 
            this.popupMenuTreeList.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barBtnItemDeleteUser)});
            this.popupMenuTreeList.Manager = this.barManager1;
            this.popupMenuTreeList.Name = "popupMenuTreeList";
            this.popupMenuTreeList.BeforePopup += new System.ComponentModel.CancelEventHandler(this.popupMenuTreeList_BeforePopup);
            // 
            // fgButtonFocus
            // 
            resources.ApplyResources(this.fgButtonFocus, "fgButtonFocus");
            this.fgButtonFocus.Name = "fgButtonFocus";
            // 
            // imageListGridPageBar
            // 
            this.imageListGridPageBar.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageListGridPageBar.ImageStream")));
            this.imageListGridPageBar.TransparentColor = System.Drawing.Color.Transparent;
            this.imageListGridPageBar.Images.SetKeyName(0, "ButtonEdit.png");
            this.imageListGridPageBar.Images.SetKeyName(1, "ButtonSave.png");
            this.imageListGridPageBar.Images.SetKeyName(2, "cancel.png");
            this.imageListGridPageBar.Images.SetKeyName(3, "lock.png");
            this.imageListGridPageBar.Images.SetKeyName(4, "unlock.gif");
            this.imageListGridPageBar.Images.SetKeyName(5, "init.png");
            // 
            // fgDevComboBoxEditComp
            // 
            resources.ApplyResources(this.fgDevComboBoxEditComp, "fgDevComboBoxEditComp");
            this.fgDevComboBoxEditComp.MenuManager = this.barManager1;
            this.fgDevComboBoxEditComp.Name = "fgDevComboBoxEditComp";
            this.fgDevComboBoxEditComp.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("fgDevComboBoxEditComp.Properties.Buttons"))))});
            this.fgDevComboBoxEditComp.Properties.HighlightedItemStyle = DevExpress.XtraEditors.HighlightStyle.Skinned;
            this.fgDevComboBoxEditComp.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            this.fgDevComboBoxEditComp.SelectedIndexChanged += new System.EventHandler(this.fgDevComboBoxEditComp_SelectedIndexChanged);
            // 
            // fgDevComboBoxEditApp
            // 
            resources.ApplyResources(this.fgDevComboBoxEditApp, "fgDevComboBoxEditApp");
            this.fgDevComboBoxEditApp.MenuManager = this.barManager1;
            this.fgDevComboBoxEditApp.Name = "fgDevComboBoxEditApp";
            this.fgDevComboBoxEditApp.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("fgDevComboBoxEditApp.Properties.Buttons"))))});
            this.fgDevComboBoxEditApp.Properties.HighlightedItemStyle = DevExpress.XtraEditors.HighlightStyle.Skinned;
            this.fgDevComboBoxEditApp.Properties.PopupSizeable = true;
            this.fgDevComboBoxEditApp.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            this.fgDevComboBoxEditApp.SelectedIndexChanged += new System.EventHandler(this.fgDevComboBoxEditApp_SelectedIndexChanged);
            // 
            // fgGroupBox2
            // 
            this.fgGroupBox2.Appearance.BackColor = System.Drawing.SystemColors.Control;
            this.fgGroupBox2.Appearance.Options.UseBackColor = true;
            this.fgGroupBox2.Controls.Add(this.tableLayoutPanel2);
            resources.ApplyResources(this.fgGroupBox2, "fgGroupBox2");
            this.fgGroupBox2.Name = "fgGroupBox2";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.tableLayoutPanel2, "tableLayoutPanel2");
            this.tableLayoutPanel2.Controls.Add(this.fgLabel2, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.fgDevComboBoxEditComp, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.fgLabelComp, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.fgDevComboBoxEditApp, 1, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            // 
            // tableLayoutPanelAll
            // 
            resources.ApplyResources(this.tableLayoutPanelAll, "tableLayoutPanelAll");
            this.tableLayoutPanelAll.Controls.Add(this.fgGroupBox2, 0, 0);
            this.tableLayoutPanelAll.Controls.Add(this.splitContainerControl1, 0, 1);
            this.tableLayoutPanelAll.Name = "tableLayoutPanelAll";
            // 
            // FormEPESSUBJ
            // 
            resources.ApplyResources(this, "$this");
            this.Controls.Add(this.tableLayoutPanelAll);
            this.Controls.Add(this.fgButtonFocus);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.Name = "FormEPESSUBJ";
            this.Load += new System.EventHandler(this.FormESSUBJ_Load);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).EndInit();
            this.splitContainerControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).EndInit();
            this.xtraTabControl1.ResumeLayout(false);
            this.xtraTabPageGroup.ResumeLayout(false);
            this.tableLayoutPanelGroup.ResumeLayout(false);
            this.tableLayoutPanelGroupCondition.ResumeLayout(false);
            this.tableLayoutPanelGroupCondition.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgtGroupName.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgtGroupAdmin.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgDevGridGroupInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tESGROUPINFOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetEPESSUBJ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewGroupInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repstryItemGroupBtnEditAdmin1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repstryItemGroupBtnEditAdmin2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEditAdmin1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEditAdmin2)).EndInit();
            this.xtraTabPageUser.ResumeLayout(false);
            this.tableLayoutPanelUser.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fgDevGridUserInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tESUSERINFOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewUserInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repstryItemComboBoxUserIsEnable)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEditDeptNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEditDeptName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repstryItemComboBoxUserDeptName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repstryItemLookUpEditUserDeptNo)).EndInit();
            this.tableLayoutPanelUserCondition.ResumeLayout(false);
            this.tableLayoutPanelUserCondition.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgDevComboBoxEditDept.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgtEname.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgtCname.Properties)).EndInit();
            this.xtraTabPageDept.ResumeLayout(false);
            this.tableLayoutPanelDept.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fgDevGridDeptInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tESDEPTINFOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewDeptInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDeptBtnEditAdmin1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDeptBtnEditAdmin2)).EndInit();
            this.tableLayoutPanelDeptCondition.ResumeLayout(false);
            this.tableLayoutPanelDeptCondition.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgtDeptEname.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgtDetpCname.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgGroupBox1)).EndInit();
            this.fgGroupBox1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.combDept.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.treeListMain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.popupMenuTreeList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgDevComboBoxEditComp.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgDevComboBoxEditApp.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgGroupBox2)).EndInit();
            this.fgGroupBox2.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanelAll.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.SimpleButton fgButtonQryGrp;
        private  DevExpress.XtraEditors.LabelControl fgLabel1;
        private DevExpress.XtraEditors.SimpleButton fgButtonQryUsr;
        private DevExpress.XtraEditors.GroupControl fgGroupBox1;
        private DevExpress.XtraTreeList.TreeList treeListMain;
        private DevExpress.Utils.ImageCollection imageCollection1;
        private  DevExpress.XtraEditors.LabelControl fgLabel2;
        private  DevExpress.XtraEditors.LabelControl fgLabelComp;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn1;
        private DevExpress.XtraBars.PopupMenu popupMenuTreeList;
        private DevExpress.XtraBars.BarManager barManager1;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private DevExpress.XtraBars.BarButtonItem barBtnItemDeleteUser;
        private DevExpress.XtraEditors.SimpleButton fgButtonUserConfig;

        private DevExpress.XtraEditors.SimpleButton fgButtonQryDept;
       
        private DevExpress.XtraEditors.SimpleButton fgButtonFocus;
        private DevExpress.XtraEditors.SplitContainerControl splitContainerControl1;
        private DevExpress.XtraTab.XtraTabControl xtraTabControl1;
        private DevExpress.XtraTab.XtraTabPage xtraTabPageGroup;
        private DevExpress.XtraTab.XtraTabPage xtraTabPageUser;
        private DevExpress.XtraTab.XtraTabPage xtraTabPageDept;
        private System.Windows.Forms.ImageList imageListGridPageBar;
        private  EF.EFDevGrid fgDevGridGroupInfo;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewGroupInfo;
        private System.Windows.Forms.BindingSource tESGROUPINFOBindingSource;
        private EP.DataSetEPESSUBJ dataSetEPESSUBJ;
        private DevExpress.XtraGrid.Columns.GridColumn colID;
        private DevExpress.XtraGrid.Columns.GridColumn colNAME;
        private DevExpress.XtraGrid.Columns.GridColumn colGROUPDESCRIPTION;
        private DevExpress.XtraGrid.Columns.GridColumn colADMINUSERNAME1;
        private DevExpress.XtraGrid.Columns.GridColumn colADMINUSERNAME2;
        private DevExpress.XtraGrid.Columns.GridColumn colAPPNAME;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEditAdmin1;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEditAdmin2;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit3;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit2;
        private  EF.EFDevGrid fgDevGridUserInfo;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewUserInfo;
        private System.Windows.Forms.BindingSource tESUSERINFOBindingSource;
        private DevExpress.XtraGrid.Columns.GridColumn colID1;
        private DevExpress.XtraGrid.Columns.GridColumn colENAME;
        private DevExpress.XtraGrid.Columns.GridColumn colCNAME;
        private DevExpress.XtraGrid.Columns.GridColumn colISENABLE;
        private DevExpress.XtraGrid.Columns.GridColumn colDEPTID;
        private DevExpress.XtraGrid.Columns.GridColumn colPASSWD_PERIOD;
        private DevExpress.XtraGrid.Columns.GridColumn colTIMETIRED;
        private DevExpress.XtraGrid.Columns.GridColumn colDEPT_ENAME;
        private DevExpress.XtraGrid.Columns.GridColumn colDEPT_CNAME;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repstryItemComboBoxUserIsEnable;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repstryItemComboBoxUserDeptName;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repstryItemLookUpEditUserDeptNo;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit4;
        private  EF.EFDevGrid fgDevGridDeptInfo;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewDeptInfo;
        private System.Windows.Forms.BindingSource tESDEPTINFOBindingSource;
        private DevExpress.XtraGrid.Columns.GridColumn colID2;
        private DevExpress.XtraGrid.Columns.GridColumn colENAME1;
        private DevExpress.XtraGrid.Columns.GridColumn colCNAME1;
        private DevExpress.XtraGrid.Columns.GridColumn colFDEPARTMENT;
        private DevExpress.XtraGrid.Columns.GridColumn colDEPART_LEVEL;
        private DevExpress.XtraGrid.Columns.GridColumn colDEPT_ADMIN1;
        private DevExpress.XtraGrid.Columns.GridColumn colDEPT_ADMIN2;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit6;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repstryItemGroupBtnEditAdmin1;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repstryItemGroupBtnEditAdmin2;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemDeptBtnEditAdmin1;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemDeptBtnEditAdmin2;
        private DevExpress.XtraEditors.ComboBoxEdit fgDevComboBoxEditApp;
        private DevExpress.XtraEditors.ComboBoxEdit fgDevComboBoxEditComp;
        private DevExpress.XtraEditors.ComboBoxEdit fgDevComboBoxEditDept;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn2;
        private DevExpress.XtraEditors.ComboBoxEdit combDept;
        private  DevExpress.XtraEditors.LabelControl fgLabel3;
        private DevExpress.XtraEditors.GroupControl fgGroupBox2;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEditDeptNo;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEditDeptName;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelAll;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelGroupCondition;
        private  DevExpress.XtraEditors.LabelControl lblGroupName;
        private  DevExpress.XtraEditors.TextEdit fgtGroupName;
        private  DevExpress.XtraEditors.LabelControl lblGroupAdmin;
        private  DevExpress.XtraEditors.TextEdit fgtGroupAdmin;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelGroup;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelUser;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelUserCondition;
        private  DevExpress.XtraEditors.LabelControl lblEname;
        private  DevExpress.XtraEditors.TextEdit fgtEname;
        private  DevExpress.XtraEditors.LabelControl lblCname;
        private  DevExpress.XtraEditors.TextEdit fgtCname;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelDept;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelDeptCondition;
        private  DevExpress.XtraEditors.LabelControl lblDeptEname;
        private  DevExpress.XtraEditors.TextEdit fgtDeptEname;
        private  DevExpress.XtraEditors.LabelControl lblDeptCname;
        private  DevExpress.XtraEditors.TextEdit fgtDetpCname;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
    }
}
