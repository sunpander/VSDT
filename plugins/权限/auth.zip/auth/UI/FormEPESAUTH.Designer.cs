﻿namespace EP
{
    partial class FormEPESAUTH
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormEPESAUTH));
            this.splitContainerControl1 = new DevExpress.XtraEditors.SplitContainerControl();
            this.xtraTabControlSubj = new DevExpress.XtraTab.XtraTabControl();
            this.xtraTabPageGroup = new DevExpress.XtraTab.XtraTabPage();
            this.tableLayoutPanelGroup = new System.Windows.Forms.TableLayoutPanel();
            this.treeListGroup = new DevExpress.XtraTreeList.TreeList();
            this.treeListColumn2 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.treeListColumn6 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.treeListColumn4 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.treeListColumn5 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.treeListColumnGID = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.imageCollection1 = new DevExpress.Utils.ImageCollection(this.components);
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.lblGEname = new DevExpress.XtraEditors.LabelControl();
            this.fgButtonGroupSave = new DevExpress.XtraEditors.SimpleButton();
            this.lblGAdmin = new DevExpress.XtraEditors.LabelControl();
            this.fgtGEname = new DevExpress.XtraEditors.TextEdit();
            this.fgButtonQryGroup = new DevExpress.XtraEditors.SimpleButton();
            this.fgtGAdmin = new DevExpress.XtraEditors.TextEdit();
            this.xtraTabPageUser = new DevExpress.XtraTab.XtraTabPage();
            this.tableLayoutPanelUser = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.lblUEname = new DevExpress.XtraEditors.LabelControl();
            this.fgButtDown = new DevExpress.XtraEditors.SimpleButton();
            this.lblPageInfo = new DevExpress.XtraEditors.LabelControl();
            this.fgtUEname = new DevExpress.XtraEditors.TextEdit();
            this.fgButtUp = new DevExpress.XtraEditors.SimpleButton();
            this.lblUCname = new DevExpress.XtraEditors.LabelControl();
            this.fgtUCname = new DevExpress.XtraEditors.TextEdit();
            this.fgButtonQryUser = new DevExpress.XtraEditors.SimpleButton();
            this.treeListUser = new DevExpress.XtraTreeList.TreeList();
            this.treeListColumn7 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.treeListColumn8 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.treeListColumn9 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.treeListColumn10 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.treeListColumnID = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.imageCollection15 = new DevExpress.Utils.ImageCollection(this.components);
            this.xtraTabControlObj = new DevExpress.XtraTab.XtraTabControl();
            this.xtraTabPageList = new DevExpress.XtraTab.XtraTabPage();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.treeListForm = new DevExpress.XtraTreeList.TreeList();
            this.treeListColumn3 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.treeListColumn11 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.lblFormName = new DevExpress.XtraEditors.LabelControl();
            this.fgtFormName = new DevExpress.XtraEditors.TextEdit();
            this.lblFormDesc = new DevExpress.XtraEditors.LabelControl();
            this.fgtFormDesc = new DevExpress.XtraEditors.TextEdit();
            this.fgButtonList = new DevExpress.XtraEditors.SimpleButton();
            this.checkNotInTree = new DevExpress.XtraEditors.CheckEdit();
            this.fgButtonRfg = new DevExpress.XtraEditors.SimpleButton();
            this.xtraTabPageTree = new DevExpress.XtraTab.XtraTabPage();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.treeListRes = new DevExpress.XtraTreeList.TreeList();
            this.treeListColumn1 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.fgLabel1 = new DevExpress.XtraEditors.LabelControl();
            this.fgButtonTree = new DevExpress.XtraEditors.SimpleButton();
            this.xtraTabPageOtherRes = new DevExpress.XtraTab.XtraTabPage();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.treeListOthRes = new DevExpress.XtraTreeList.TreeList();
            this.treeListColumn12 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.treeListColumn13 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.treeListColumnAuthCode = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.CheckEditWrite = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.CheckEditExecute = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.lblOthName = new DevExpress.XtraEditors.LabelControl();
            this.fgtOthName = new DevExpress.XtraEditors.TextEdit();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.comboOthResType = new DevExpress.XtraEditors.ComboBoxEdit();
            this.fgButtonOthRes = new DevExpress.XtraEditors.SimpleButton();
            this.execute = new System.Windows.Forms.CheckBox();
            this.write = new System.Windows.Forms.CheckBox();
            this.read = new System.Windows.Forms.CheckBox();
            this.lblR = new DevExpress.XtraTab.XtraTabPage();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.treeListResGroup = new DevExpress.XtraTreeList.TreeList();
            this.treeListColumnRGName = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.treeListColumnRGID = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.imageCollectionRG = new DevExpress.Utils.ImageCollection(this.components);
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.lblRGName = new DevExpress.XtraEditors.LabelControl();
            this.fgButtonRfgreshRG = new DevExpress.XtraEditors.SimpleButton();
            this.fgButtonResGroup = new DevExpress.XtraEditors.SimpleButton();
            this.fgtRGName = new DevExpress.XtraEditors.TextEdit();
            this.labelControlCheck = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.checkEditNested = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.fgDevCheckEdit1 = new DevExpress.XtraEditors.CheckEdit();
            this.fgDevCheckEdit2 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControlComp = new DevExpress.XtraEditors.LabelControl();
            this.barManager1 = new DevExpress.XtraBars.BarManager(this.components);
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.barButtonItemAuthSource = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItemSelAll = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItemUnSelAll = new DevExpress.XtraBars.BarButtonItem();
            this.popupMenuList = new DevExpress.XtraBars.PopupMenu(this.components);
            this.tableLayoutPanelAll = new System.Windows.Forms.TableLayoutPanel();
            this.fgGroupBox1 = new DevExpress.XtraEditors.GroupControl();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.comboComp = new DevExpress.XtraEditors.ComboBoxEdit();
            this.comboApp = new DevExpress.XtraEditors.ComboBoxEdit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).BeginInit();
            this.splitContainerControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControlSubj)).BeginInit();
            this.xtraTabControlSubj.SuspendLayout();
            this.xtraTabPageGroup.SuspendLayout();
            this.tableLayoutPanelGroup.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.treeListGroup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).BeginInit();
            this.tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgtGEname.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgtGAdmin.Properties)).BeginInit();
            this.xtraTabPageUser.SuspendLayout();
            this.tableLayoutPanelUser.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgtUEname.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgtUCname.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.treeListUser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageCollection15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControlObj)).BeginInit();
            this.xtraTabControlObj.SuspendLayout();
            this.xtraTabPageList.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.treeListForm)).BeginInit();
            this.tableLayoutPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgtFormName.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgtFormDesc.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkNotInTree.Properties)).BeginInit();
            this.xtraTabPageTree.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.treeListRes)).BeginInit();
            this.tableLayoutPanel7.SuspendLayout();
            this.xtraTabPageOtherRes.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.treeListOthRes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CheckEditWrite)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CheckEditExecute)).BeginInit();
            this.tableLayoutPanel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgtOthName.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboOthResType.Properties)).BeginInit();
            this.lblR.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.treeListResGroup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageCollectionRG)).BeginInit();
            this.tableLayoutPanel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgtRGName.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEditNested.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgDevCheckEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgDevCheckEdit2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.popupMenuList)).BeginInit();
            this.tableLayoutPanelAll.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgGroupBox1)).BeginInit();
            this.fgGroupBox1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.comboComp.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboApp.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainerControl1
            // 
            this.splitContainerControl1.CaptionLocation = DevExpress.Utils.Locations.Top;
            resources.ApplyResources(this.splitContainerControl1, "splitContainerControl1");
            this.splitContainerControl1.Name = "splitContainerControl1";
            this.splitContainerControl1.Panel1.Controls.Add(this.xtraTabControlSubj);
            this.splitContainerControl1.Panel1.MinSize = 400;
            this.splitContainerControl1.Panel2.CaptionLocation = DevExpress.Utils.Locations.Top;
            this.splitContainerControl1.Panel2.Controls.Add(this.xtraTabControlObj);
            this.splitContainerControl1.Panel2.MinSize = 470;
            this.splitContainerControl1.ShowCaption = true;
            this.splitContainerControl1.SplitterPosition = 600;
            // 
            // xtraTabControlSubj
            // 
            resources.ApplyResources(this.xtraTabControlSubj, "xtraTabControlSubj");
            this.xtraTabControlSubj.Name = "xtraTabControlSubj";
            this.xtraTabControlSubj.SelectedTabPage = this.xtraTabPageGroup;
            this.xtraTabControlSubj.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.xtraTabPageGroup,
            this.xtraTabPageUser});
            this.xtraTabControlSubj.SelectedPageChanging += new DevExpress.XtraTab.TabPageChangingEventHandler(this.xtraTabControl2_SelectedPageChanging);
            this.xtraTabControlSubj.SelectedPageChanged += new DevExpress.XtraTab.TabPageChangedEventHandler(this.xtraTabControlSubj_SelectedPageChanged);
            // 
            // xtraTabPageGroup
            // 
            this.xtraTabPageGroup.Controls.Add(this.tableLayoutPanelGroup);
            this.xtraTabPageGroup.Name = "xtraTabPageGroup";
            resources.ApplyResources(this.xtraTabPageGroup, "xtraTabPageGroup");
            // 
            // tableLayoutPanelGroup
            // 
            resources.ApplyResources(this.tableLayoutPanelGroup, "tableLayoutPanelGroup");
            this.tableLayoutPanelGroup.Controls.Add(this.treeListGroup, 0, 1);
            this.tableLayoutPanelGroup.Controls.Add(this.tableLayoutPanel3, 0, 0);
            this.tableLayoutPanelGroup.Name = "tableLayoutPanelGroup";
            // 
            // treeListGroup
            // 
            this.treeListGroup.Appearance.Empty.BackColor = System.Drawing.Color.Transparent;
            this.treeListGroup.Appearance.Empty.Options.UseBackColor = true;
            this.treeListGroup.Columns.AddRange(new DevExpress.XtraTreeList.Columns.TreeListColumn[] {
            this.treeListColumn2,
            this.treeListColumn6,
            this.treeListColumn4,
            this.treeListColumn5,
            this.treeListColumnGID});
            resources.ApplyResources(this.treeListGroup, "treeListGroup");
            this.treeListGroup.Name = "treeListGroup";
            this.treeListGroup.OptionsBehavior.AllowExpandOnDblClick = false;
            this.treeListGroup.OptionsBehavior.AllowIndeterminateCheckState = true;
            this.treeListGroup.OptionsBehavior.Editable = false;
            this.treeListGroup.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.treeListGroup.OptionsView.EnableAppearanceEvenRow = true;
            this.treeListGroup.OptionsView.EnableAppearanceOddRow = true;
            this.treeListGroup.SelectImageList = this.imageCollection1;
            this.treeListGroup.BeforeCheckNode += new DevExpress.XtraTreeList.CheckNodeEventHandler(this.treeListGroup_BeforeCheckNode);
            this.treeListGroup.MouseDown += new System.Windows.Forms.MouseEventHandler(this.treeListGroup_MouseDown);
            this.treeListGroup.CustomDrawNodeCell += new DevExpress.XtraTreeList.CustomDrawNodeCellEventHandler(this.treeListGroup_CustomDrawNodeCell);
            this.treeListGroup.AfterFocusNode += new DevExpress.XtraTreeList.NodeEventHandler(this.treeListGroup_AfterFocusNode);
            this.treeListGroup.BeforeFocusNode += new DevExpress.XtraTreeList.BeforeFocusNodeEventHandler(this.treeListGroup_BeforeFocusNode);
            this.treeListGroup.DoubleClick += new System.EventHandler(this.treeListGroup_DoubleClick);
            this.treeListGroup.AfterCheckNode += new DevExpress.XtraTreeList.NodeEventHandler(this.treeListGroup_AfterCheckNode);
            // 
            // treeListColumn2
            // 
            resources.ApplyResources(this.treeListColumn2, "treeListColumn2");
            this.treeListColumn2.FieldName = "name";
            this.treeListColumn2.Name = "treeListColumn2";
            // 
            // treeListColumn6
            // 
            resources.ApplyResources(this.treeListColumn6, "treeListColumn6");
            this.treeListColumn6.FieldName = "groupdescription";
            this.treeListColumn6.Name = "treeListColumn6";
            // 
            // treeListColumn4
            // 
            resources.ApplyResources(this.treeListColumn4, "treeListColumn4");
            this.treeListColumn4.FieldName = "adminusername1";
            this.treeListColumn4.Name = "treeListColumn4";
            this.treeListColumn4.OptionsColumn.AllowSort = false;
            // 
            // treeListColumn5
            // 
            resources.ApplyResources(this.treeListColumn5, "treeListColumn5");
            this.treeListColumn5.FieldName = "adminusername2";
            this.treeListColumn5.Name = "treeListColumn5";
            this.treeListColumn5.OptionsColumn.AllowSort = false;
            // 
            // treeListColumnGID
            // 
            resources.ApplyResources(this.treeListColumnGID, "treeListColumnGID");
            this.treeListColumnGID.FieldName = "id";
            this.treeListColumnGID.Name = "treeListColumnGID";
            // 
            // imageCollection1
            // 
            this.imageCollection1.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("imageCollection1.ImageStream")));
            this.imageCollection1.Images.SetKeyName(0, "07.gif");
            this.imageCollection1.Images.SetKeyName(1, "grp.gif");
            this.imageCollection1.Images.SetKeyName(2, "Tech Support1.png");
            // 
            // tableLayoutPanel3
            // 
            resources.ApplyResources(this.tableLayoutPanel3, "tableLayoutPanel3");
            this.tableLayoutPanel3.Controls.Add(this.lblGEname, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.fgButtonGroupSave, 5, 0);
            this.tableLayoutPanel3.Controls.Add(this.lblGAdmin, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.fgtGEname, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.fgButtonQryGroup, 4, 0);
            this.tableLayoutPanel3.Controls.Add(this.fgtGAdmin, 3, 0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            // 
            // lblGEname
            // 
            resources.ApplyResources(this.lblGEname, "lblGEname");
            this.lblGEname.Name = "lblGEname";
            // 
            // fgButtonGroupSave
            // 
            resources.ApplyResources(this.fgButtonGroupSave, "fgButtonGroupSave");
            this.fgButtonGroupSave.Name = "fgButtonGroupSave";
            this.fgButtonGroupSave.Click += new System.EventHandler(this.fgButtonGroupSave_Click);
            // 
            // lblGAdmin
            // 
            resources.ApplyResources(this.lblGAdmin, "lblGAdmin");
            this.lblGAdmin.Name = "lblGAdmin";
            // 
            // fgtGEname
            // 
            resources.ApplyResources(this.fgtGEname, "fgtGEname");
            this.fgtGEname.Name = "fgtGEname";
            // 
            // fgButtonQryGroup
            // 
            resources.ApplyResources(this.fgButtonQryGroup, "fgButtonQryGroup");
            this.fgButtonQryGroup.Name = "fgButtonQryGroup";
            this.fgButtonQryGroup.Click += new System.EventHandler(this.QryGroup_Click);
            // 
            // fgtGAdmin
            // 
            resources.ApplyResources(this.fgtGAdmin, "fgtGAdmin");
            this.fgtGAdmin.Name = "fgtGAdmin";
            // 
            // xtraTabPageUser
            // 
            this.xtraTabPageUser.Controls.Add(this.tableLayoutPanelUser);
            this.xtraTabPageUser.Name = "xtraTabPageUser";
            resources.ApplyResources(this.xtraTabPageUser, "xtraTabPageUser");
            this.xtraTabPageUser.Resize += new System.EventHandler(this.xtraTabPageUser_Resize);
            // 
            // tableLayoutPanelUser
            // 
            resources.ApplyResources(this.tableLayoutPanelUser, "tableLayoutPanelUser");
            this.tableLayoutPanelUser.Controls.Add(this.tableLayoutPanel4, 0, 0);
            this.tableLayoutPanelUser.Controls.Add(this.treeListUser, 0, 1);
            this.tableLayoutPanelUser.Name = "tableLayoutPanelUser";
            // 
            // tableLayoutPanel4
            // 
            resources.ApplyResources(this.tableLayoutPanel4, "tableLayoutPanel4");
            this.tableLayoutPanel4.Controls.Add(this.lblUEname, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.fgButtDown, 7, 0);
            this.tableLayoutPanel4.Controls.Add(this.lblPageInfo, 6, 0);
            this.tableLayoutPanel4.Controls.Add(this.fgtUEname, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.fgButtUp, 5, 0);
            this.tableLayoutPanel4.Controls.Add(this.lblUCname, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.fgtUCname, 3, 0);
            this.tableLayoutPanel4.Controls.Add(this.fgButtonQryUser, 4, 0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            // 
            // lblUEname
            // 
            resources.ApplyResources(this.lblUEname, "lblUEname");
            this.lblUEname.Name = "lblUEname";
            // 
            // fgButtDown
            // 
            this.fgButtDown.Appearance.Font = new System.Drawing.Font("宋体", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.fgButtDown.Appearance.Options.UseFont = true;
            resources.ApplyResources(this.fgButtDown, "fgButtDown");
            this.fgButtDown.Name = "fgButtDown";
            this.fgButtDown.TabStop = false;
            this.fgButtDown.Click += new System.EventHandler(this.fgButtDown_Click);
            // 
            // lblPageInfo
            // 
            resources.ApplyResources(this.lblPageInfo, "lblPageInfo");
            this.lblPageInfo.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.lblPageInfo.Appearance.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblPageInfo.Appearance.Options.UseBackColor = true;
            this.lblPageInfo.Appearance.Options.UseFont = true;
            this.lblPageInfo.Name = "lblPageInfo";
            // 
            // fgtUEname
            // 
            resources.ApplyResources(this.fgtUEname, "fgtUEname");
            this.fgtUEname.Name = "fgtUEname";
            // 
            // fgButtUp
            // 
            this.fgButtUp.Appearance.Font = new System.Drawing.Font("宋体", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.fgButtUp.Appearance.Options.UseFont = true;
            resources.ApplyResources(this.fgButtUp, "fgButtUp");
            this.fgButtUp.Name = "fgButtUp";
            this.fgButtUp.TabStop = false;
            this.fgButtUp.Click += new System.EventHandler(this.fgButtUp_Click);
            // 
            // lblUCname
            // 
            resources.ApplyResources(this.lblUCname, "lblUCname");
            this.lblUCname.Name = "lblUCname";
            // 
            // fgtUCname
            // 
            resources.ApplyResources(this.fgtUCname, "fgtUCname");
            this.fgtUCname.Name = "fgtUCname";
            // 
            // fgButtonQryUser
            // 
            resources.ApplyResources(this.fgButtonQryUser, "fgButtonQryUser");
            this.fgButtonQryUser.Name = "fgButtonQryUser";
            this.fgButtonQryUser.Click += new System.EventHandler(this.QryUser_Click);
            // 
            // treeListUser
            // 
            this.treeListUser.Appearance.Empty.BackColor = System.Drawing.Color.Transparent;
            this.treeListUser.Appearance.Empty.Options.UseBackColor = true;
            this.treeListUser.Columns.AddRange(new DevExpress.XtraTreeList.Columns.TreeListColumn[] {
            this.treeListColumn7,
            this.treeListColumn8,
            this.treeListColumn9,
            this.treeListColumn10,
            this.treeListColumnID});
            resources.ApplyResources(this.treeListUser, "treeListUser");
            this.treeListUser.Name = "treeListUser";
            this.treeListUser.OptionsBehavior.AllowExpandOnDblClick = false;
            this.treeListUser.OptionsBehavior.AllowIndeterminateCheckState = true;
            this.treeListUser.OptionsBehavior.Editable = false;
            this.treeListUser.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.treeListUser.OptionsView.EnableAppearanceEvenRow = true;
            this.treeListUser.OptionsView.EnableAppearanceOddRow = true;
            this.treeListUser.SelectImageList = this.imageCollection15;
            this.treeListUser.MouseDown += new System.Windows.Forms.MouseEventHandler(this.treeListUser_MouseDown);
            this.treeListUser.AfterFocusNode += new DevExpress.XtraTreeList.NodeEventHandler(this.treeListUser_AfterFocusNode);
            this.treeListUser.BeforeFocusNode += new DevExpress.XtraTreeList.BeforeFocusNodeEventHandler(this.treeListUser_BeforeFocusNode);
            this.treeListUser.DoubleClick += new System.EventHandler(this.treeListUser_DoubleClick);
            // 
            // treeListColumn7
            // 
            resources.ApplyResources(this.treeListColumn7, "treeListColumn7");
            this.treeListColumn7.FieldName = "ename";
            this.treeListColumn7.Name = "treeListColumn7";
            this.treeListColumn7.OptionsColumn.AllowSort = false;
            // 
            // treeListColumn8
            // 
            resources.ApplyResources(this.treeListColumn8, "treeListColumn8");
            this.treeListColumn8.FieldName = "cname";
            this.treeListColumn8.Name = "treeListColumn8";
            this.treeListColumn8.OptionsColumn.AllowSort = false;
            // 
            // treeListColumn9
            // 
            resources.ApplyResources(this.treeListColumn9, "treeListColumn9");
            this.treeListColumn9.FieldName = "adminuserename1";
            this.treeListColumn9.Name = "treeListColumn9";
            this.treeListColumn9.OptionsColumn.AllowEdit = false;
            this.treeListColumn9.OptionsColumn.AllowSort = false;
            // 
            // treeListColumn10
            // 
            resources.ApplyResources(this.treeListColumn10, "treeListColumn10");
            this.treeListColumn10.FieldName = "adminuserename2";
            this.treeListColumn10.Name = "treeListColumn10";
            this.treeListColumn10.OptionsColumn.AllowEdit = false;
            this.treeListColumn10.OptionsColumn.AllowSort = false;
            // 
            // treeListColumnID
            // 
            resources.ApplyResources(this.treeListColumnID, "treeListColumnID");
            this.treeListColumnID.FieldName = "id";
            this.treeListColumnID.Name = "treeListColumnID";
            // 
            // imageCollection15
            // 
            this.imageCollection15.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("imageCollection15.ImageStream")));
            this.imageCollection15.Images.SetKeyName(0, "Tech Support.ico");
            this.imageCollection15.Images.SetKeyName(1, "formnew.png");
            this.imageCollection15.Images.SetKeyName(2, "butt.png");
            this.imageCollection15.Images.SetKeyName(3, "07.gif");
            this.imageCollection15.Images.SetKeyName(4, "module.png");
            this.imageCollection15.Images.SetKeyName(5, "grp.gif");
            this.imageCollection15.Images.SetKeyName(6, "关闭.png");
            this.imageCollection15.Images.SetKeyName(7, "打开.png");
            // 
            // xtraTabControlObj
            // 
            resources.ApplyResources(this.xtraTabControlObj, "xtraTabControlObj");
            this.xtraTabControlObj.Name = "xtraTabControlObj";
            this.xtraTabControlObj.SelectedTabPage = this.xtraTabPageList;
            this.xtraTabControlObj.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.xtraTabPageList,
            this.xtraTabPageTree,
            this.xtraTabPageOtherRes,
            this.lblR});
            this.xtraTabControlObj.SelectedPageChanging += new DevExpress.XtraTab.TabPageChangingEventHandler(this.xtraTabControl1_SelectedPageChanging);
            // 
            // xtraTabPageList
            // 
            this.xtraTabPageList.Controls.Add(this.tableLayoutPanel2);
            this.xtraTabPageList.Name = "xtraTabPageList";
            resources.ApplyResources(this.xtraTabPageList, "xtraTabPageList");
            // 
            // tableLayoutPanel2
            // 
            resources.ApplyResources(this.tableLayoutPanel2, "tableLayoutPanel2");
            this.tableLayoutPanel2.Controls.Add(this.treeListForm, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel5, 0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            // 
            // treeListForm
            // 
            this.treeListForm.Appearance.Empty.BackColor = System.Drawing.Color.Transparent;
            this.treeListForm.Appearance.Empty.Options.UseBackColor = true;
            this.treeListForm.Appearance.EvenRow.BackColor = System.Drawing.Color.Transparent;
            this.treeListForm.Appearance.EvenRow.Options.UseBackColor = true;
            this.treeListForm.Appearance.OddRow.BackColor = System.Drawing.Color.Transparent;
            this.treeListForm.Appearance.OddRow.Options.UseBackColor = true;
            this.treeListForm.Columns.AddRange(new DevExpress.XtraTreeList.Columns.TreeListColumn[] {
            this.treeListColumn3,
            this.treeListColumn11});
            resources.ApplyResources(this.treeListForm, "treeListForm");
            this.treeListForm.Name = "treeListForm";
            this.treeListForm.OptionsBehavior.AllowExpandOnDblClick = false;
            this.treeListForm.OptionsBehavior.AllowIncrementalSearch = true;
            this.treeListForm.OptionsBehavior.Editable = false;
            this.treeListForm.OptionsBehavior.EnableFiltering = true;
            this.treeListForm.OptionsBehavior.ExpandNodeOnDrag = false;
            this.treeListForm.OptionsBehavior.ImmediateEditor = false;
            this.treeListForm.OptionsBehavior.ResizeNodes = false;
            this.treeListForm.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.treeListForm.OptionsView.EnableAppearanceEvenRow = true;
            this.treeListForm.OptionsView.EnableAppearanceOddRow = true;
            this.treeListForm.OptionsView.ShowCheckBoxes = true;
            this.treeListForm.OptionsView.ShowIndicator = false;
            this.treeListForm.SelectImageList = this.imageCollection15;
            this.treeListForm.BeforeCheckNode += new DevExpress.XtraTreeList.CheckNodeEventHandler(this.treeListForm_BeforeCheckNode);
            this.treeListForm.MouseDown += new System.Windows.Forms.MouseEventHandler(this.treeListForm_MouseDown);
            this.treeListForm.MouseUp += new System.Windows.Forms.MouseEventHandler(this.treeListForm_MouseUp);
            this.treeListForm.CustomDrawNodeCell += new DevExpress.XtraTreeList.CustomDrawNodeCellEventHandler(this.treeListForm_CustomDrawNodeCell);
            this.treeListForm.DoubleClick += new System.EventHandler(this.treeListForm_DoubleClick);
            this.treeListForm.Click += new System.EventHandler(this.treeListForm_Click);
            this.treeListForm.AfterCheckNode += new DevExpress.XtraTreeList.NodeEventHandler(this.treeListForm_AfterCheckNode);
            // 
            // treeListColumn3
            // 
            resources.ApplyResources(this.treeListColumn3, "treeListColumn3");
            this.treeListColumn3.FieldName = "cname";
            this.treeListColumn3.Name = "treeListColumn3";
            // 
            // treeListColumn11
            // 
            resources.ApplyResources(this.treeListColumn11, "treeListColumn11");
            this.treeListColumn11.FieldName = "ename";
            this.treeListColumn11.Name = "treeListColumn11";
            // 
            // tableLayoutPanel5
            // 
            resources.ApplyResources(this.tableLayoutPanel5, "tableLayoutPanel5");
            this.tableLayoutPanel5.Controls.Add(this.lblFormName, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.fgtFormName, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.lblFormDesc, 2, 0);
            this.tableLayoutPanel5.Controls.Add(this.fgtFormDesc, 3, 0);
            this.tableLayoutPanel5.Controls.Add(this.fgButtonList, 6, 0);
            this.tableLayoutPanel5.Controls.Add(this.checkNotInTree, 4, 0);
            this.tableLayoutPanel5.Controls.Add(this.fgButtonRfg, 5, 0);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            // 
            // lblFormName
            // 
            resources.ApplyResources(this.lblFormName, "lblFormName");
            this.lblFormName.Name = "lblFormName";
            // 
            // fgtFormName
            // 
            resources.ApplyResources(this.fgtFormName, "fgtFormName");
            this.fgtFormName.Name = "fgtFormName";
            this.fgtFormName.Properties.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            // 
            // lblFormDesc
            // 
            resources.ApplyResources(this.lblFormDesc, "lblFormDesc");
            this.lblFormDesc.Name = "lblFormDesc";
            // 
            // fgtFormDesc
            // 
            resources.ApplyResources(this.fgtFormDesc, "fgtFormDesc");
            this.fgtFormDesc.Name = "fgtFormDesc";
            // 
            // fgButtonList
            // 
            resources.ApplyResources(this.fgButtonList, "fgButtonList");
            this.fgButtonList.Name = "fgButtonList";
            this.fgButtonList.Click += new System.EventHandler(this.fgButtonList_Click);
            // 
            // checkNotInTree
            // 
            resources.ApplyResources(this.checkNotInTree, "checkNotInTree");
            this.checkNotInTree.Name = "checkNotInTree";
            this.checkNotInTree.Properties.AutoWidth = true;
            this.checkNotInTree.Properties.Caption = resources.GetString("checkNotInTree.Properties.Caption");
            // 
            // fgButtonRfg
            // 
            resources.ApplyResources(this.fgButtonRfg, "fgButtonRfg");
            this.fgButtonRfg.Name = "fgButtonRfg";
            this.fgButtonRfg.Click += new System.EventHandler(this.fgButtonRfg_Click);
            // 
            // xtraTabPageTree
            // 
            this.xtraTabPageTree.Controls.Add(this.tableLayoutPanel6);
            this.xtraTabPageTree.Name = "xtraTabPageTree";
            resources.ApplyResources(this.xtraTabPageTree, "xtraTabPageTree");
            this.xtraTabPageTree.Resize += new System.EventHandler(this.xtraTabPageTree_Resize);
            // 
            // tableLayoutPanel6
            // 
            resources.ApplyResources(this.tableLayoutPanel6, "tableLayoutPanel6");
            this.tableLayoutPanel6.Controls.Add(this.treeListRes, 0, 1);
            this.tableLayoutPanel6.Controls.Add(this.tableLayoutPanel7, 0, 0);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            // 
            // treeListRes
            // 
            this.treeListRes.Appearance.Empty.BackColor = System.Drawing.Color.Transparent;
            this.treeListRes.Appearance.Empty.Options.UseBackColor = true;
            this.treeListRes.Appearance.EvenRow.BackColor = System.Drawing.Color.Transparent;
            this.treeListRes.Appearance.EvenRow.BackColor2 = System.Drawing.Color.Transparent;
            this.treeListRes.Appearance.EvenRow.Options.UseBackColor = true;
            this.treeListRes.Appearance.OddRow.BackColor = System.Drawing.Color.Transparent;
            this.treeListRes.Appearance.OddRow.BackColor2 = System.Drawing.Color.Transparent;
            this.treeListRes.Appearance.OddRow.Options.UseBackColor = true;
            this.treeListRes.Columns.AddRange(new DevExpress.XtraTreeList.Columns.TreeListColumn[] {
            this.treeListColumn1});
            resources.ApplyResources(this.treeListRes, "treeListRes");
            this.treeListRes.Name = "treeListRes";
            this.treeListRes.OptionsBehavior.AllowExpandOnDblClick = false;
            this.treeListRes.OptionsBehavior.AllowIndeterminateCheckState = true;
            this.treeListRes.OptionsBehavior.Editable = false;
            this.treeListRes.OptionsBehavior.EnableFiltering = true;
            this.treeListRes.OptionsBehavior.ExpandNodeOnDrag = false;
            this.treeListRes.OptionsBehavior.ImmediateEditor = false;
            this.treeListRes.OptionsBehavior.ResizeNodes = false;
            this.treeListRes.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.treeListRes.OptionsView.EnableAppearanceEvenRow = true;
            this.treeListRes.OptionsView.EnableAppearanceOddRow = true;
            this.treeListRes.OptionsView.ShowCheckBoxes = true;
            this.treeListRes.OptionsView.ShowColumns = false;
            this.treeListRes.OptionsView.ShowHorzLines = false;
            this.treeListRes.OptionsView.ShowIndicator = false;
            this.treeListRes.OptionsView.ShowVertLines = false;
            this.treeListRes.SelectImageList = this.imageCollection15;
            this.treeListRes.BeforeCheckNode += new DevExpress.XtraTreeList.CheckNodeEventHandler(this.treeListRes_BeforeCheckNode);
            this.treeListRes.MouseDown += new System.Windows.Forms.MouseEventHandler(this.treeListRes_MouseDown);
            this.treeListRes.MouseUp += new System.Windows.Forms.MouseEventHandler(this.treeListRes_MouseUp);
            this.treeListRes.CustomDrawNodeCell += new DevExpress.XtraTreeList.CustomDrawNodeCellEventHandler(this.treeListRes_CustomDrawNodeCell);
            this.treeListRes.AfterCollapse += new DevExpress.XtraTreeList.NodeEventHandler(this.treeListRes_AfterCollapse);
            this.treeListRes.AfterExpand += new DevExpress.XtraTreeList.NodeEventHandler(this.treeListRes_AfterExpand);
            this.treeListRes.DoubleClick += new System.EventHandler(this.treeListRes_DoubleClick);
            this.treeListRes.Click += new System.EventHandler(this.treeListRes_Click);
            this.treeListRes.AfterCheckNode += new DevExpress.XtraTreeList.NodeEventHandler(this.treeListRes_AfterCheckNode);
            // 
            // treeListColumn1
            // 
            resources.ApplyResources(this.treeListColumn1, "treeListColumn1");
            this.treeListColumn1.FieldName = "treeListColumn1";
            this.treeListColumn1.Name = "treeListColumn1";
            // 
            // tableLayoutPanel7
            // 
            resources.ApplyResources(this.tableLayoutPanel7, "tableLayoutPanel7");
            this.tableLayoutPanel7.Controls.Add(this.fgLabel1, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.fgButtonTree, 1, 0);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            // 
            // fgLabel1
            // 
            resources.ApplyResources(this.fgLabel1, "fgLabel1");
            this.fgLabel1.Name = "fgLabel1";
            // 
            // fgButtonTree
            // 
            resources.ApplyResources(this.fgButtonTree, "fgButtonTree");
            this.fgButtonTree.Name = "fgButtonTree";
            this.fgButtonTree.Click += new System.EventHandler(this.fgButtonTree_Click);
            // 
            // xtraTabPageOtherRes
            // 
            this.xtraTabPageOtherRes.Controls.Add(this.tableLayoutPanel8);
            this.xtraTabPageOtherRes.Controls.Add(this.execute);
            this.xtraTabPageOtherRes.Controls.Add(this.write);
            this.xtraTabPageOtherRes.Controls.Add(this.read);
            this.xtraTabPageOtherRes.Name = "xtraTabPageOtherRes";
            resources.ApplyResources(this.xtraTabPageOtherRes, "xtraTabPageOtherRes");
            // 
            // tableLayoutPanel8
            // 
            resources.ApplyResources(this.tableLayoutPanel8, "tableLayoutPanel8");
            this.tableLayoutPanel8.Controls.Add(this.treeListOthRes, 0, 1);
            this.tableLayoutPanel8.Controls.Add(this.tableLayoutPanel9, 0, 0);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            // 
            // treeListOthRes
            // 
            this.treeListOthRes.Appearance.Empty.BackColor = System.Drawing.Color.Transparent;
            this.treeListOthRes.Appearance.Empty.Options.UseBackColor = true;
            this.treeListOthRes.Appearance.EvenRow.BackColor = System.Drawing.Color.Transparent;
            this.treeListOthRes.Appearance.EvenRow.Options.UseBackColor = true;
            this.treeListOthRes.Appearance.OddRow.BackColor = System.Drawing.Color.Transparent;
            this.treeListOthRes.Appearance.OddRow.Options.UseBackColor = true;
            this.treeListOthRes.Columns.AddRange(new DevExpress.XtraTreeList.Columns.TreeListColumn[] {
            this.treeListColumn12,
            this.treeListColumn13,
            this.treeListColumnAuthCode});
            resources.ApplyResources(this.treeListOthRes, "treeListOthRes");
            this.treeListOthRes.Name = "treeListOthRes";
            this.treeListOthRes.OptionsBehavior.AllowExpandOnDblClick = false;
            this.treeListOthRes.OptionsBehavior.AllowIncrementalSearch = true;
            this.treeListOthRes.OptionsBehavior.Editable = false;
            this.treeListOthRes.OptionsBehavior.EnableFiltering = true;
            this.treeListOthRes.OptionsBehavior.ExpandNodeOnDrag = false;
            this.treeListOthRes.OptionsBehavior.ImmediateEditor = false;
            this.treeListOthRes.OptionsBehavior.ResizeNodes = false;
            this.treeListOthRes.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.treeListOthRes.OptionsView.EnableAppearanceEvenRow = true;
            this.treeListOthRes.OptionsView.EnableAppearanceOddRow = true;
            this.treeListOthRes.OptionsView.ShowCheckBoxes = true;
            this.treeListOthRes.OptionsView.ShowIndicator = false;
            this.treeListOthRes.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.CheckEditWrite,
            this.CheckEditExecute});
            this.treeListOthRes.BeforeCheckNode += new DevExpress.XtraTreeList.CheckNodeEventHandler(this.treeListOthRes_BeforeCheckNode);
            this.treeListOthRes.MouseUp += new System.Windows.Forms.MouseEventHandler(this.treeListOthRes_MouseUp);
            this.treeListOthRes.CustomDrawNodeCell += new DevExpress.XtraTreeList.CustomDrawNodeCellEventHandler(this.treeListOthRes_CustomDrawNodeCell);
            this.treeListOthRes.AfterCheckNode += new DevExpress.XtraTreeList.NodeEventHandler(this.treeListOthRes_AfterCheckNode);
            // 
            // treeListColumn12
            // 
            resources.ApplyResources(this.treeListColumn12, "treeListColumn12");
            this.treeListColumn12.FieldName = "name";
            this.treeListColumn12.Name = "treeListColumn12";
            // 
            // treeListColumn13
            // 
            resources.ApplyResources(this.treeListColumn13, "treeListColumn13");
            this.treeListColumn13.FieldName = "desc";
            this.treeListColumn13.Name = "treeListColumn13";
            // 
            // treeListColumnAuthCode
            // 
            resources.ApplyResources(this.treeListColumnAuthCode, "treeListColumnAuthCode");
            this.treeListColumnAuthCode.FieldName = "权限";
            this.treeListColumnAuthCode.Name = "treeListColumnAuthCode";
            // 
            // CheckEditWrite
            // 
            resources.ApplyResources(this.CheckEditWrite, "CheckEditWrite");
            this.CheckEditWrite.Name = "CheckEditWrite";
            this.CheckEditWrite.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            // 
            // CheckEditExecute
            // 
            resources.ApplyResources(this.CheckEditExecute, "CheckEditExecute");
            this.CheckEditExecute.Name = "CheckEditExecute";
            this.CheckEditExecute.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            // 
            // tableLayoutPanel9
            // 
            resources.ApplyResources(this.tableLayoutPanel9, "tableLayoutPanel9");
            this.tableLayoutPanel9.Controls.Add(this.lblOthName, 0, 0);
            this.tableLayoutPanel9.Controls.Add(this.fgtOthName, 1, 0);
            this.tableLayoutPanel9.Controls.Add(this.labelControl3, 2, 0);
            this.tableLayoutPanel9.Controls.Add(this.comboOthResType, 3, 0);
            this.tableLayoutPanel9.Controls.Add(this.fgButtonOthRes, 4, 0);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            // 
            // lblOthName
            // 
            resources.ApplyResources(this.lblOthName, "lblOthName");
            this.lblOthName.Name = "lblOthName";
            // 
            // fgtOthName
            // 
            resources.ApplyResources(this.fgtOthName, "fgtOthName");
            this.fgtOthName.Name = "fgtOthName";
            // 
            // labelControl3
            // 
            resources.ApplyResources(this.labelControl3, "labelControl3");
            this.labelControl3.Name = "labelControl3";
            // 
            // comboOthResType
            // 
            resources.ApplyResources(this.comboOthResType, "comboOthResType");
            this.comboOthResType.Name = "comboOthResType";
            this.comboOthResType.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("comboOthResType.Properties.Buttons"))))});
            this.comboOthResType.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            this.comboOthResType.SelectedIndexChanged += new System.EventHandler(this.comboOthResType_SelectedIndexChanged);
            // 
            // fgButtonOthRes
            // 
            resources.ApplyResources(this.fgButtonOthRes, "fgButtonOthRes");
            this.fgButtonOthRes.Name = "fgButtonOthRes";
            this.fgButtonOthRes.Click += new System.EventHandler(this.fgButtonOthRes_Click);
            // 
            // execute
            // 
            this.execute.BackColor = System.Drawing.Color.Transparent;
            this.execute.Checked = true;
            this.execute.CheckState = System.Windows.Forms.CheckState.Checked;
            resources.ApplyResources(this.execute, "execute");
            this.execute.Name = "execute";
            this.execute.UseVisualStyleBackColor = false;
            // 
            // write
            // 
            this.write.BackColor = System.Drawing.Color.Transparent;
            this.write.Checked = true;
            this.write.CheckState = System.Windows.Forms.CheckState.Checked;
            resources.ApplyResources(this.write, "write");
            this.write.Name = "write";
            this.write.UseVisualStyleBackColor = false;
            // 
            // read
            // 
            this.read.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.read, "read");
            this.read.Name = "read";
            this.read.UseVisualStyleBackColor = false;
            // 
            // lblR
            // 
            this.lblR.Controls.Add(this.tableLayoutPanel10);
            this.lblR.Name = "lblR";
            resources.ApplyResources(this.lblR, "lblR");
            // 
            // tableLayoutPanel10
            // 
            resources.ApplyResources(this.tableLayoutPanel10, "tableLayoutPanel10");
            this.tableLayoutPanel10.Controls.Add(this.treeListResGroup, 0, 1);
            this.tableLayoutPanel10.Controls.Add(this.tableLayoutPanel11, 0, 0);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            // 
            // treeListResGroup
            // 
            this.treeListResGroup.Appearance.Empty.BackColor = System.Drawing.Color.Transparent;
            this.treeListResGroup.Appearance.Empty.Options.UseBackColor = true;
            this.treeListResGroup.Appearance.EvenRow.BackColor = System.Drawing.Color.Transparent;
            this.treeListResGroup.Appearance.EvenRow.BackColor2 = System.Drawing.Color.Transparent;
            this.treeListResGroup.Appearance.EvenRow.Options.UseBackColor = true;
            this.treeListResGroup.Appearance.OddRow.BackColor = System.Drawing.Color.Transparent;
            this.treeListResGroup.Appearance.OddRow.BackColor2 = System.Drawing.Color.Transparent;
            this.treeListResGroup.Appearance.OddRow.Options.UseBackColor = true;
            this.treeListResGroup.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.treeListResGroup.Columns.AddRange(new DevExpress.XtraTreeList.Columns.TreeListColumn[] {
            this.treeListColumnRGName,
            this.treeListColumnRGID});
            resources.ApplyResources(this.treeListResGroup, "treeListResGroup");
            this.treeListResGroup.Name = "treeListResGroup";
            this.treeListResGroup.OptionsBehavior.AllowExpandOnDblClick = false;
            this.treeListResGroup.OptionsBehavior.AllowIndeterminateCheckState = true;
            this.treeListResGroup.OptionsBehavior.Editable = false;
            this.treeListResGroup.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.treeListResGroup.OptionsView.EnableAppearanceEvenRow = true;
            this.treeListResGroup.OptionsView.EnableAppearanceOddRow = true;
            this.treeListResGroup.OptionsView.ShowCheckBoxes = true;
            this.treeListResGroup.OptionsView.ShowColumns = false;
            this.treeListResGroup.OptionsView.ShowHorzLines = false;
            this.treeListResGroup.OptionsView.ShowIndicator = false;
            this.treeListResGroup.OptionsView.ShowVertLines = false;
            this.treeListResGroup.SelectImageList = this.imageCollectionRG;
            this.treeListResGroup.BeforeCheckNode += new DevExpress.XtraTreeList.CheckNodeEventHandler(this.treeListResGroup_BeforeCheckNode);
            this.treeListResGroup.MouseDown += new System.Windows.Forms.MouseEventHandler(this.treeListResGroup_MouseDown);
            this.treeListResGroup.CustomDrawNodeCell += new DevExpress.XtraTreeList.CustomDrawNodeCellEventHandler(this.treeListResGroup_CustomDrawNodeCell);
            this.treeListResGroup.DoubleClick += new System.EventHandler(this.treeListResGroup_DoubleClick);
            this.treeListResGroup.Click += new System.EventHandler(this.treeListResGroup_Click);
            this.treeListResGroup.AfterCheckNode += new DevExpress.XtraTreeList.NodeEventHandler(this.treeListResGroup_AfterCheckNode);
            // 
            // treeListColumnRGName
            // 
            resources.ApplyResources(this.treeListColumnRGName, "treeListColumnRGName");
            this.treeListColumnRGName.FieldName = "name";
            this.treeListColumnRGName.Name = "treeListColumnRGName";
            // 
            // treeListColumnRGID
            // 
            resources.ApplyResources(this.treeListColumnRGID, "treeListColumnRGID");
            this.treeListColumnRGID.FieldName = "id";
            this.treeListColumnRGID.Name = "treeListColumnRGID";
            // 
            // imageCollectionRG
            // 
            this.imageCollectionRG.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("imageCollectionRG.ImageStream")));
            this.imageCollectionRG.Images.SetKeyName(0, "User Folder.png");
            this.imageCollectionRG.Images.SetKeyName(1, "formnew.png");
            this.imageCollectionRG.Images.SetKeyName(2, "butt.png");
            this.imageCollectionRG.Images.SetKeyName(3, "ButtonEdit.png");
            this.imageCollectionRG.Images.SetKeyName(4, "ButtonNew.png");
            this.imageCollectionRG.Images.SetKeyName(5, "ButtonSave.png");
            this.imageCollectionRG.Images.SetKeyName(6, "打开.png");
            this.imageCollectionRG.Images.SetKeyName(7, "关闭.png");
            this.imageCollectionRG.Images.SetKeyName(8, "othres2.png");
            // 
            // tableLayoutPanel11
            // 
            resources.ApplyResources(this.tableLayoutPanel11, "tableLayoutPanel11");
            this.tableLayoutPanel11.Controls.Add(this.lblRGName, 0, 0);
            this.tableLayoutPanel11.Controls.Add(this.fgButtonRfgreshRG, 2, 0);
            this.tableLayoutPanel11.Controls.Add(this.fgButtonResGroup, 3, 0);
            this.tableLayoutPanel11.Controls.Add(this.fgtRGName, 1, 0);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            // 
            // lblRGName
            // 
            resources.ApplyResources(this.lblRGName, "lblRGName");
            this.lblRGName.Name = "lblRGName";
            // 
            // fgButtonRfgreshRG
            // 
            resources.ApplyResources(this.fgButtonRfgreshRG, "fgButtonRfgreshRG");
            this.fgButtonRfgreshRG.Name = "fgButtonRfgreshRG";
            this.fgButtonRfgreshRG.Click += new System.EventHandler(this.fgButtonRfgreshRG_Click);
            // 
            // fgButtonResGroup
            // 
            resources.ApplyResources(this.fgButtonResGroup, "fgButtonResGroup");
            this.fgButtonResGroup.Name = "fgButtonResGroup";
            this.fgButtonResGroup.Click += new System.EventHandler(this.fgButtonResGroup_Click);
            // 
            // fgtRGName
            // 
            resources.ApplyResources(this.fgtRGName, "fgtRGName");
            this.fgtRGName.Name = "fgtRGName";
            // 
            // labelControlCheck
            // 
            resources.ApplyResources(this.labelControlCheck, "labelControlCheck");
            this.labelControlCheck.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControlCheck.Appearance.Options.UseFont = true;
            this.labelControlCheck.Name = "labelControlCheck";
            // 
            // labelControl2
            // 
            resources.ApplyResources(this.labelControl2, "labelControl2");
            this.labelControl2.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl2.Appearance.Options.UseFont = true;
            this.labelControl2.Name = "labelControl2";
            // 
            // checkEditNested
            // 
            resources.ApplyResources(this.checkEditNested, "checkEditNested");
            this.checkEditNested.Name = "checkEditNested";
            this.checkEditNested.Properties.AutoWidth = true;
            this.checkEditNested.Properties.Caption = resources.GetString("checkEditNested.Properties.Caption");
            // 
            // labelControl1
            // 
            resources.ApplyResources(this.labelControl1, "labelControl1");
            this.labelControl1.Name = "labelControl1";
            // 
            // fgDevCheckEdit1
            // 
            resources.ApplyResources(this.fgDevCheckEdit1, "fgDevCheckEdit1");
            this.fgDevCheckEdit1.Name = "fgDevCheckEdit1";
            this.fgDevCheckEdit1.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fgDevCheckEdit1.Properties.Appearance.Options.UseFont = true;
            this.fgDevCheckEdit1.Properties.AutoWidth = true;
            this.fgDevCheckEdit1.Properties.Caption = resources.GetString("fgDevCheckEdit1.Properties.Caption");
            this.fgDevCheckEdit1.Properties.CheckStyle = DevExpress.XtraEditors.Controls.CheckStyles.Radio;
            this.fgDevCheckEdit1.Properties.RadioGroupIndex = 1;
            this.fgDevCheckEdit1.TabStop = false;
            // 
            // fgDevCheckEdit2
            // 
            resources.ApplyResources(this.fgDevCheckEdit2, "fgDevCheckEdit2");
            this.fgDevCheckEdit2.Name = "fgDevCheckEdit2";
            this.fgDevCheckEdit2.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fgDevCheckEdit2.Properties.Appearance.Options.UseFont = true;
            this.fgDevCheckEdit2.Properties.AutoWidth = true;
            this.fgDevCheckEdit2.Properties.Caption = resources.GetString("fgDevCheckEdit2.Properties.Caption");
            this.fgDevCheckEdit2.Properties.CheckStyle = DevExpress.XtraEditors.Controls.CheckStyles.Radio;
            this.fgDevCheckEdit2.Properties.RadioGroupIndex = 1;
            this.fgDevCheckEdit2.TabStop = false;
            this.fgDevCheckEdit2.CheckedChanged += new System.EventHandler(this.fgDevCheckEdit2_CheckedChanged);
            // 
            // labelControlComp
            // 
            resources.ApplyResources(this.labelControlComp, "labelControlComp");
            this.labelControlComp.Name = "labelControlComp";
            // 
            // barManager1
            // 
            this.barManager1.DockControls.Add(this.barDockControlTop);
            this.barManager1.DockControls.Add(this.barDockControlBottom);
            this.barManager1.DockControls.Add(this.barDockControlLeft);
            this.barManager1.DockControls.Add(this.barDockControlRight);
            this.barManager1.Form = this;
            this.barManager1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.barButtonItemAuthSource,
            this.barButtonItemSelAll,
            this.barButtonItemUnSelAll});
            this.barManager1.MaxItemId = 3;
            // 
            // barButtonItemAuthSource
            // 
            resources.ApplyResources(this.barButtonItemAuthSource, "barButtonItemAuthSource");
            this.barButtonItemAuthSource.Id = 0;
            this.barButtonItemAuthSource.Name = "barButtonItemAuthSource";
            this.barButtonItemAuthSource.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItemAuthSource_ItemClick);
            // 
            // barButtonItemSelAll
            // 
            resources.ApplyResources(this.barButtonItemSelAll, "barButtonItemSelAll");
            this.barButtonItemSelAll.Id = 1;
            this.barButtonItemSelAll.Name = "barButtonItemSelAll";
            this.barButtonItemSelAll.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItemSelAll_ItemClick);
            // 
            // barButtonItemUnSelAll
            // 
            resources.ApplyResources(this.barButtonItemUnSelAll, "barButtonItemUnSelAll");
            this.barButtonItemUnSelAll.Id = 2;
            this.barButtonItemUnSelAll.Name = "barButtonItemUnSelAll";
            this.barButtonItemUnSelAll.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItemUnSelAll_ItemClick);
            // 
            // popupMenuList
            // 
            this.popupMenuList.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItemAuthSource),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItemSelAll, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItemUnSelAll)});
            this.popupMenuList.Manager = this.barManager1;
            this.popupMenuList.Name = "popupMenuList";
            this.popupMenuList.BeforePopup += new System.ComponentModel.CancelEventHandler(this.popupMenuList_BeforePopup);
            // 
            // tableLayoutPanelAll
            // 
            resources.ApplyResources(this.tableLayoutPanelAll, "tableLayoutPanelAll");
            this.tableLayoutPanelAll.Controls.Add(this.splitContainerControl1, 0, 1);
            this.tableLayoutPanelAll.Controls.Add(this.fgGroupBox1, 0, 0);
            this.tableLayoutPanelAll.Name = "tableLayoutPanelAll";
            // 
            // fgGroupBox1
            // 
            this.fgGroupBox1.Appearance.BackColor = System.Drawing.SystemColors.Control;
            this.fgGroupBox1.Appearance.Options.UseBackColor = true;
            this.fgGroupBox1.Controls.Add(this.tableLayoutPanel1);
            resources.ApplyResources(this.fgGroupBox1, "fgGroupBox1");
            this.fgGroupBox1.Name = "fgGroupBox1";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.tableLayoutPanel1, "tableLayoutPanel1");
            this.tableLayoutPanel1.Controls.Add(this.labelControlCheck, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelControl2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.fgDevCheckEdit1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelControlComp, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.fgDevCheckEdit2, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.checkEditNested, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelControl1, 7, 0);
            this.tableLayoutPanel1.Controls.Add(this.comboComp, 6, 0);
            this.tableLayoutPanel1.Controls.Add(this.comboApp, 8, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            // 
            // comboComp
            // 
            resources.ApplyResources(this.comboComp, "comboComp");
            this.comboComp.MenuManager = this.barManager1;
            this.comboComp.Name = "comboComp";
            this.comboComp.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("comboComp.Properties.Buttons"))))});
            this.comboComp.Properties.HighlightedItemStyle = DevExpress.XtraEditors.HighlightStyle.Skinned;
            this.comboComp.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            this.comboComp.SelectedIndexChanged += new System.EventHandler(this.comboComp_SelectedIndexChanged);
            // 
            // comboApp
            // 
            resources.ApplyResources(this.comboApp, "comboApp");
            this.comboApp.MenuManager = this.barManager1;
            this.comboApp.Name = "comboApp";
            this.comboApp.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("comboApp.Properties.Buttons"))))});
            this.comboApp.Properties.HighlightedItemStyle = DevExpress.XtraEditors.HighlightStyle.Skinned;
            this.comboApp.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            this.comboApp.SelectedIndexChanged += new System.EventHandler(this.comboApp_SelectedIndexChanged);
            // 
            // FormEPESAUTH
            // 
            resources.ApplyResources(this, "$this");
            this.Controls.Add(this.tableLayoutPanelAll);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.Name = "FormEPESAUTH";
            this.Load += new System.EventHandler(this.FormESAUTH_Load);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).EndInit();
            this.splitContainerControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControlSubj)).EndInit();
            this.xtraTabControlSubj.ResumeLayout(false);
            this.xtraTabPageGroup.ResumeLayout(false);
            this.tableLayoutPanelGroup.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.treeListGroup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).EndInit();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgtGEname.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgtGAdmin.Properties)).EndInit();
            this.xtraTabPageUser.ResumeLayout(false);
            this.tableLayoutPanelUser.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgtUEname.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgtUCname.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.treeListUser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageCollection15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControlObj)).EndInit();
            this.xtraTabControlObj.ResumeLayout(false);
            this.xtraTabPageList.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.treeListForm)).EndInit();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgtFormName.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgtFormDesc.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkNotInTree.Properties)).EndInit();
            this.xtraTabPageTree.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.treeListRes)).EndInit();
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel7.PerformLayout();
            this.xtraTabPageOtherRes.ResumeLayout(false);
            this.tableLayoutPanel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.treeListOthRes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CheckEditWrite)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CheckEditExecute)).EndInit();
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgtOthName.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboOthResType.Properties)).EndInit();
            this.lblR.ResumeLayout(false);
            this.tableLayoutPanel10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.treeListResGroup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageCollectionRG)).EndInit();
            this.tableLayoutPanel11.ResumeLayout(false);
            this.tableLayoutPanel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgtRGName.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEditNested.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgDevCheckEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgDevCheckEdit2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.popupMenuList)).EndInit();
            this.tableLayoutPanelAll.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fgGroupBox1)).EndInit();
            this.fgGroupBox1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.comboComp.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboApp.Properties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private  DevExpress.XtraEditors.CheckEdit fgDevCheckEdit1;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private  DevExpress.XtraEditors.CheckEdit fgDevCheckEdit2;
        private DevExpress.XtraEditors.LabelControl labelControlComp;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn4;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn6;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn2;
        private DevExpress.XtraTreeList.TreeList treeListGroup;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn5;
        private DevExpress.Utils.ImageCollection imageCollection15;
        private DevExpress.XtraEditors.SplitContainerControl splitContainerControl1;
        private DevExpress.XtraEditors.SimpleButton fgButtonQryGroup;
        private DevExpress.XtraTab.XtraTabControl xtraTabControlObj;
        private DevExpress.XtraTab.XtraTabPage xtraTabPageList;
        private DevExpress.XtraTab.XtraTabPage xtraTabPageTree;
        private DevExpress.XtraTab.XtraTabControl xtraTabControlSubj;
        private DevExpress.XtraTab.XtraTabPage xtraTabPageGroup;
        private DevExpress.XtraTab.XtraTabPage xtraTabPageUser;
        private DevExpress.XtraEditors.SimpleButton fgButtonQryUser;
        private  DevExpress.XtraEditors.LabelControl lblPageInfo;
        private DevExpress.XtraEditors.SimpleButton fgButtUp;
        private DevExpress.XtraEditors.SimpleButton fgButtDown;
        private DevExpress.XtraEditors.CheckEdit checkEditNested;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LabelControl labelControlCheck;
        private DevExpress.XtraEditors.SimpleButton fgButtonGroupSave;
        private DevExpress.XtraEditors.SimpleButton fgButtonList;
        private DevExpress.XtraTreeList.TreeList treeListForm;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn3;
        private  DevExpress.XtraEditors.LabelControl fgLabel1;
        private DevExpress.XtraEditors.SimpleButton fgButtonTree;
        private DevExpress.XtraTreeList.TreeList treeListRes;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn1;
        private DevExpress.XtraTreeList.TreeList treeListUser;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn7;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn8;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn9;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn10;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn11;
        private DevExpress.XtraEditors.SimpleButton fgButtonRfg;
        private DevExpress.Utils.ImageCollection imageCollection1;
        private DevExpress.XtraTab.XtraTabPage xtraTabPageOtherRes;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraTreeList.TreeList treeListOthRes;
        private DevExpress.XtraEditors.SimpleButton fgButtonOthRes;
        private DevExpress.XtraEditors.ComboBoxEdit comboOthResType;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn12;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn13;
        private  System.Windows.Forms.CheckBox execute;
        private  System.Windows.Forms.CheckBox write;
        private  System.Windows.Forms.CheckBox read;
        private DevExpress.XtraBars.BarManager barManager1;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private DevExpress.XtraBars.PopupMenu popupMenuList;
        private DevExpress.XtraBars.BarButtonItem barButtonItemAuthSource;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit CheckEditWrite;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit CheckEditExecute;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumnAuthCode;
        private DevExpress.XtraTab.XtraTabPage lblR;
        private DevExpress.XtraTreeList.TreeList treeListResGroup;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumnRGName;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumnGID;
        private DevExpress.XtraEditors.SimpleButton fgButtonResGroup;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumnID;
        private DevExpress.XtraBars.BarButtonItem barButtonItemSelAll;
        private DevExpress.XtraBars.BarButtonItem barButtonItemUnSelAll;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumnRGID;
        private DevExpress.Utils.ImageCollection imageCollectionRG;
        private DevExpress.XtraEditors.SimpleButton fgButtonRfgreshRG;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelAll;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private DevExpress.XtraEditors.ComboBoxEdit comboComp;
        private DevExpress.XtraEditors.ComboBoxEdit comboApp;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelGroup;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private  DevExpress.XtraEditors.LabelControl lblGEname;
        private  DevExpress.XtraEditors.LabelControl lblGAdmin;
        private  DevExpress.XtraEditors.TextEdit fgtGEname;
        private  DevExpress.XtraEditors.TextEdit fgtGAdmin;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelUser;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private  DevExpress.XtraEditors.LabelControl lblUEname;
        private  DevExpress.XtraEditors.TextEdit fgtUEname;
        private  DevExpress.XtraEditors.LabelControl lblUCname;
        private  DevExpress.XtraEditors.TextEdit fgtUCname;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private  DevExpress.XtraEditors.LabelControl lblFormName;
        private  DevExpress.XtraEditors.TextEdit fgtFormName;
        private  DevExpress.XtraEditors.LabelControl lblFormDesc;
        private  DevExpress.XtraEditors.TextEdit fgtFormDesc;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private  DevExpress.XtraEditors.LabelControl lblOthName;
        private  DevExpress.XtraEditors.TextEdit fgtOthName;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private  DevExpress.XtraEditors.LabelControl lblRGName;
        private  DevExpress.XtraEditors.TextEdit fgtRGName;
        private DevExpress.XtraEditors.GroupControl fgGroupBox1;
        private DevExpress.XtraEditors.CheckEdit checkNotInTree;
    }
}
